<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<HTML>
<HEAD>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<TITLE>Nagios</TITLE>

<STYLE type="text/css">

<!--

	TABLE.NavBarTitle { font-family: verdana,arial,serif; background-color: black; border: thin solid white; padding: 1; }
	TD.NavBarTitle { font-family: verdana,arial,serif; background-color: black; color: #DEE7C6; font-size: 10pt; font-weight: bold; text-decoration: none; }
	.NavBarItem { font-family: verdana,arial,serif; background-color: black; color: #DEE7C6; font-size: 8pt; font-weight: bold; text-decoration: none; }
	.NavBarSearchItem { font-family: verdana,arial,serif; background-color: black; color: #DEE7C6; font-size: 8pt; }
	INPUT.NavBarSearchItem { font-family: verdana,arial,serif; background-color: white; color: black; font-size: 8pt; }
	BODY.navbar { font-family: verdana,arial,serif; background-color: white; color: black;  background-color: black }

-->
	
</STYLE>
<SCRIPT LANGUAGE="JavaScript">
function hide_em() {
	document.all.item('host1').style.visibility='hidden'
}
</SCRIPT>
</HEAD>

<BODY CLASS='navbar' onLoad="hide_em()">

<SCRIPT LANGUAGE="JavaScript">
<!--

if(parseInt(navigator.appVersion.substring(0,1))>=3){
  doton = new Image(13,14);
  doton.src = "images/orangedot.gif";
  dotoff = new Image(13,14);
  dotoff.src = "images/greendot.gif";
  }

function switchdot(name,on){
  if(parseInt(navigator.appVersion.substring(0,1))>=3){
    image = eval("" + (on == 1 ? "doton.src" : "dotoff.src"));
    document[name].src=image;
    }
  }


//-->
</SCRIPT>
<SCRIPT language=JavaScript src="http://itweb.guidehome.com/js/autocomplete.js" type=text/javascript></SCRIPT>

	<form method="get" action="/nagios/cgi-bin/status.cgi" target="main">
	<input type='hidden' name='navbarsearch' value='1'>

<table width="150" border="0">
  <tr>
    <td>
      <div align="center"><a href="http://www.nagios.org" target="_blank"><img src="images/sblogo.jpg" border="0" alt="Nagios"></a></div>
    </td>
  </tr>
</table>

<table width="150">
  <tr>
    <td>
      <table width="100%" class="NavBarTitle" cellspacing="0">
        <tr>
  	  <td class="NavBarTitle">Monitoring</td>
	</tr>
      </table>
    </td>
  </tr>
</table>

<table width="150" border="0" cellpadding=0 cellspacing=0>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="tac-dot"></td>
    <td nowrap width=134><a href="/nagios/cgi-bin/tac.cgi" target="main" onMouseOver="switchdot('tac-dot',1)" onMouseOut="switchdot('tac-dot',0)" class="NavBarItem">Tactical Overview</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="status-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/status.cgi?host=all" target="main" onMouseOver="switchdot('status-dot',1)" onMouseOut="switchdot('status-dot',0)" class="NavBarItem">Service Detail</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="hoststatus-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/status.cgi?hostgroup=all&style=hostdetail" target="main" onMouseOver="switchdot('hoststatus-dot',1)" onMouseOut="switchdot('hoststatus-dot',0)" class="NavBarItem">Host Detail</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="hgstatus-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/status.cgi?hostgroup=all&style=overview" target="main" onMouseOver="switchdot('hgstatus-dot',1)" onMouseOut="switchdot('hgstatus-dot',0)" class="NavBarItem">Hostgroup Overview</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="hgstatus2-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/status.cgi?hostgroup=all&style=summary" target="main" onMouseOver="switchdot('hgstatus2-dot',1)" onMouseOut="switchdot('hgstatus2-dot',0)" class="NavBarItem">Hostgroup Summary</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="hgstatus3-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/status.cgi?hostgroup=all&style=grid" target="main" onMouseOver="switchdot('hgstatus3-dot',1)" onMouseOut="switchdot('hgstatus3-dot',0)" class="NavBarItem">Hostgroup Grid</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="sgstatus1-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/status.cgi?servicegroup=all&style=overview" target="main" onMouseOver="switchdot('sgstatus1-dot',1)" onMouseOut="switchdot('sgstatus1-dot',0)" class="NavBarItem">Servicegroup Overview</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="sgstatus2-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/status.cgi?servicegroup=all&style=summary" target="main" onMouseOver="switchdot('sgstatus2-dot',1)" onMouseOut="switchdot('sgstatus2-dot',0)" class="NavBarItem">Servicegroup Summary</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="sgstatus3-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/status.cgi?servicegroup=all&style=grid" target="main" onMouseOver="switchdot('sgstatus3-dot',1)" onMouseOut="switchdot('sgstatus3-dot',0)" class="NavBarItem">Servicegroup Grid</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="statuswrl-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/statuswrl.cgi?host=all" target="main" onMouseOver="switchdot('statuswrl-dot',1)" onMouseOut="switchdot('statuswrl-dot',0)" class="NavBarItem">3-D Status Map</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="statusmap-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/statusmap.cgi?host=all" target="main" onMouseOver="switchdot('statusmap-dot',1)" onMouseOut="switchdot('statusmap-dot',0)" class="NavBarItem">Status Map</a></td>
  </tr>
    <td colspan="2" height="10"></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="svcproblems-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/status.cgi?host=all&servicestatustypes=28" target="main" onMouseOver="switchdot('svcproblems-dot',1)" onMouseOut="switchdot('svcproblems-dot',0)" class="NavBarItem">Service Problems</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="hostproblems-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/status.cgi?hostgroup=all&style=hostdetail&hoststatustypes=12" target="main" onMouseOver="switchdot('hostproblems-dot',1)" onMouseOut="switchdot('hostproblems-dot',0)" class="NavBarItem">Host Problems</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="outages-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/outages.cgi" target="main" onMouseOver="switchdot('outages-dot',1)" onMouseOut="switchdot('outages-dot',0)" class="NavBarItem">Network Outages</a></td>
  </tr>
  <tr> 
    <td colspan="2" height="10"></td>
  </tr>
  <tr> 
    <td width=13></td>
    <td nowrap class="NavBarSearchItem">Show Host:</td>
  </tr>
  <tr> 
    <td width=13></td>
    <td nowrap>

<?

printf('<INPUT TYPE="text" NAME="host" VALUE="" ONKEYUP="autoComplete(this,this.form.host1,\'value\',true)" size=15>');

//	<input type='text' name='host' size='15' class="NavBarSearchItem">
?>	
    </td>
  </tr>
  <tr> 
    <td colspan="2" height="10"></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="comment-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/extinfo.cgi?&type=3" target="main" onMouseOver="switchdot('comment-dot',1)" onMouseOut="switchdot('comment-dot',0)" class="NavBarItem">Comments</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="downtime-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/extinfo.cgi?&type=6" target="main" onMouseOver="switchdot('downtime-dot',1)" onMouseOut="switchdot('downtime-dot',0)" class="NavBarItem">Downtime</a></td>
  </tr>
  <tr> 
    <td colspan="2" height="10"></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="processinfo-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/extinfo.cgi?&type=0" target="main" onMouseOver="switchdot('processinfo-dot',1)" onMouseOut="switchdot('processinfo-dot',0)" class="NavBarItem">Process Info</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="performance-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/extinfo.cgi?&type=4" target="main" onMouseOver="switchdot('performance-dot',1)" onMouseOut="switchdot('performance-dot',0)" class="NavBarItem">Performance Info</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="queue-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/extinfo.cgi?&type=7" target="main" onMouseOver="switchdot('queue-dot',1)" onMouseOut="switchdot('queue-dot',0)" class="NavBarItem">Scheduling Queue</a></td>
  </tr>
  <tr>
    <td colspan="2" height="10"></td>
  </tr>
</table>

<table width="150">
  <tr>
    <td>
      <table width="100%" class="NavBarTitle" cellspacing="0">
        <tr>
  	  <td class="NavBarTitle">Reporting</td>
	</tr>
      </table>
    </td>
  </tr>
</table>

<table width="150" border="0" cellpadding=0 cellspacing=0>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="trends-dot1"></td>
    <td nowrap width=134><a href="/graphs/ntthumbs.htm" target="main" onMouseOver="switchdot('trends-dot1',1)" onMouseOut="switchdot('trends-dot1',0)" class="NavBarItem">NT Server Graphs</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="trends-dot2"></td>
    <td nowrap width=134><a href="/graphs/wasthumbs.htm" target="main" onMouseOver="switchdot('trends-dot2',1)" onMouseOut="switchdot('trends-dot2',0)" class="NavBarItem">WAS Graphs</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="trends-dot"></td>
    <td nowrap width=134><a href="/nagios/cgi-bin/trends.cgi" target="main" onMouseOver="switchdot('trends-dot',1)" onMouseOut="switchdot('trends-dot',0)" class="NavBarItem">Trends</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="avail-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/avail.cgi" target="main" onMouseOver="switchdot('avail-dot',1)" onMouseOut="switchdot('avail-dot',0)" class="NavBarItem">Availability</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="histogram-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/histogram.cgi" target="main" onMouseOver="switchdot('histogram-dot',1)" onMouseOut="switchdot('histogram-dot',0)" class="NavBarItem">Alert Histogram</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="history-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/history.cgi?host=all" target="main" onMouseOver="switchdot('history-dot',1)" onMouseOut="switchdot('history-dot',0)" class="NavBarItem">Alert History</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="summary-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/summary.cgi" target="main" onMouseOver="switchdot('summary-dot',1)" onMouseOut="switchdot('summary-dot',0)" class="NavBarItem">Alert Summary</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="notifications-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/notifications.cgi?contact=all" target="main" onMouseOver="switchdot('notifications-dot',1)" onMouseOut="switchdot('notifications-dot',0)" class="NavBarItem">Notifications</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="logfile-dot"></td>
    <td nowrap><a href="/nagios/cgi-bin/showlog.cgi" target="main" onMouseOver="switchdot('logfile-dot',1)" onMouseOut="switchdot('logfile-dot',0)" class="NavBarItem">Event Log</a></td>
  </tr>
  <tr>
    <td colspan="2" height="10"></td>
  </tr>
</table>


<table width="150">
  <tr>
    <td>
      <table width="100%" class="NavBarTitle" cellspacing="0">
        <tr>
  	  <td class="NavBarTitle">Configuration</td>
	</tr>
      </table>
    </td>
  </tr>
</table>

<table width="150" border="0" cellpadding=0 cellspacing=0>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="config-dot"></td>
    <td nowrap width=134><a href="/nagios/cgi-bin/config.cgi" target="main" onMouseOver="switchdot('config-dot',1)" onMouseOut="switchdot('config-dot',0)" class="NavBarItem">View 
      Running Config</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="config-dot1"></td>
    <td nowrap><a href="/nagiosweb/hostlist.php" target="main" onMouseOver="switchdot('config-dot1',1)" onMouseOut="switchdot('config-dot1',0)" class="NavBarItem">Hosts</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="config-dot2"></td>
    <td nowrap><a href="/nagiosweb/hostgrouplist.php" target="main" onMouseOver="switchdot('config-dot2',1)" onMouseOut="switchdot('config-dot2',0)" class="NavBarItem">Host 
      Groups</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="config-dot3"></td>
    <td nowrap><a href="/nagiosweb/servicelist.php" target="main" onMouseOver="switchdot('config-dot3',1)" onMouseOut="switchdot('config-dot3',0)" class="NavBarItem">Services</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="config-dot4"></td>
    <td nowrap><a href="/nagiosweb/contactlist.php" target="main" onMouseOver="switchdot('config-dot4',1)" onMouseOut="switchdot('config-dot4',0)" class="NavBarItem">Contacts</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="config-dot5"></td>
    <td nowrap><a href="/nagiosweb/contactgrouplist.php" target="main" onMouseOver="switchdot('config-dot5',1)" onMouseOut="switchdot('config-dot5',0)" class="NavBarItem">Contact 
      Groups</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="config-dot6"></td>
    <td nowrap><a href="/nagiosweb/timeperiodlist.php" target="main" onMouseOver="switchdot('config-dot6',1)" onMouseOut="switchdot('config-dot6',0)" class="NavBarItem">Time Periods</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="config-dot7"></td>
    <td nowrap><a href="/nagiosweb/checkcommandlist.php" target="main" onMouseOver="switchdot('config-dot7',1)" onMouseOut="switchdot('config-dot7',0)" class="NavBarItem">Check Commands</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="config-dot8"></td>
    <td nowrap><a href="/nagiosweb/notifylist.php" target="main" onMouseOver="switchdot('config-dot8',1)" onMouseOut="switchdot('config-dot8',0)" class="NavBarItem">Notify Commands</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="config-dot9"></td>
    <td nowrap><a href="/nagiosweb/runscript.php" target="main" onMouseOver="switchdot('config-dot9',1)" onMouseOut="switchdot('config-dot9',0)" class="NavBarItem">Write Config</a></td>
  </tr>
  <tr> 
    <td width=13><img src="images/greendot.gif" width="13" height="14" name="docs-dot"></td>
    <td nowrap><a href="docs/index.html" target="main" onMouseOver="switchdot('docs-dot',1)" onMouseOut="switchdot('docs-dot',0)" class="NavBarItem">Documentation</a></td>
  </tr>
</table>
<?php
$db = mysql_connect("localhost", "mysql", "mysql");
mysql_select_db("nagiosweb");
$query = mysql_query("SELECT host_name FROM hosts ORDER BY host_name");
echo '<select name="host1" onChange="this.form.host.value=this.host1[this.selectedIndex].value">';
echo "<option value=\"\" selected></option>\n";

while ($currhost=mysql_fetch_array($query)) {
	printf("<option value=\"%s\">%s</option>\n", $currhost["host_name"], $currhost["host_name"]);
}
echo '</select>';
?>

</form>

</BODY>
</HTML>
