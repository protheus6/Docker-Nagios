-- phpMyAdmin SQL Dump
-- version 2.6.4
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Apr 21, 2006 at 11:27 AM
-- Server version: 4.1.14
-- PHP Version: 5.0.5
-- 
-- Database: `nagiosweb-dist`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `servicetemplates`
-- 

CREATE TABLE `servicetemplates` (
  `servicetemplate_id` int(11) NOT NULL auto_increment,
  `service_description` varchar(100) NOT NULL default '',
  `active_checks_enabled` text NOT NULL,
  `parallelize_check` text NOT NULL,
  `obsess_over_service` text NOT NULL,
  `check_freshness` text NOT NULL,
  `notifications_enabled` text NOT NULL,
  `event_handler_enabled` text NOT NULL,
  `flap_detection_enabled` text NOT NULL,
  `process_perf_data` text NOT NULL,
  `retain_status_information` text NOT NULL,
  `is_volatile` text NOT NULL,
  `register` text NOT NULL,
  `check_period` text NOT NULL,
  `notification_period` text NOT NULL,
  `notification_interval` text NOT NULL,
  `normal_check_interval` text NOT NULL,
  `retry_check_interval` text NOT NULL,
  `max_check_attempts` text NOT NULL,
  `notification_options` text NOT NULL,
  `check_command` text NOT NULL,
  `command_args` text NOT NULL,
  `freshness_threshold` text NOT NULL,
  `low_flap_threshold` text NOT NULL,
  `high_flap_threshold` text NOT NULL,
  `event_handler` text NOT NULL,
  `stalking_options` text NOT NULL,
  `passive_checks_enabled` text NOT NULL,
  PRIMARY KEY  (`servicetemplate_id`),
  UNIQUE KEY `service_id` (`servicetemplate_id`,`service_description`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `servicetemplates`
-- 

