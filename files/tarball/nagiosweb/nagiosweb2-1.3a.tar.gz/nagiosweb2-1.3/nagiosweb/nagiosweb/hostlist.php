<?php
//include("include.php");
include("dbconfig.php");
//include("top.php");

?>
<center><a href="hosts.php">Add New Host</a></center><br>

<table align="center" border="1" cellpadding="2" cellspacing="0" width="700">
<tr align="center"><td><b>Host Name</b></td><td><b>Alias/Short Description</b></td><td><b>Address</b></td></tr>
<?
$hostquery = mysql_query("SELECT host_id, host_name, alias, address FROM hosts ORDER BY host_name");
while ($myhost = mysql_fetch_array($hostquery)) {
	printf('<tr><td><a href="hosts.php?action=hostlookup&host_id=%s">%s</a></td><td>%s</td><td>%s</td>', $myhost["host_id"], $myhost["host_name"], $myhost["alias"], $myhost["address"]);
	echo "\n";
}

?>
</table>

