<?php
//include("include.php");
include("dbconfig.php");
//include("top.php");

?>
<table align="center" border="1" cellpadding="2" cellspacing="0" width="700">
<tr align="center"><td><b>Service Description</b></td><td><b>Check Period</b></td><td><b>Notify Period</b></td><td><b>Member Hosts</b></td><td><b>Member Host Groups</b></td></tr>
<?
$servicequery = mysql_query("SELECT service_id, service_description, check_period, notification_period FROM services ORDER BY service_description");
while ($myservice = mysql_fetch_array($servicequery)) {
	$check_period=$myservice["check_period"];
	$checkq=mysql_query("SELECT timeperiod_name FROM timeperiods WHERE timeperiod_id='$check_period'");
	$check_period=mysql_result($checkq, 0);
	$notify_period=$myservice["notification_period"];
	$notifyq=mysql_query("SELECT timeperiod_name FROM timeperiods WHERE timeperiod_id='$notify_period'");
	$notify_period=mysql_result($notifyq, 0);
	printf('<tr valign=top><td><a href="services.php?action=servicelookup&service_id=%s">%s</a></td><td>%s</td><td>%s</td>', $myservice["service_id"], $myservice["service_description"], $check_period, $notify_period);
	echo "<td><table border=1 width=100%>\n";
	$service_id = $myservice["service_id"];
	$hostquery = mysql_query("SELECT DISTINCT hosts.host_name, hosts.host_id FROM hosts, services WHERE services.service_id='$service_id' AND hosts.host_id=services.host_id ORDER BY hosts.host_name");
	while ($myhost=mysql_fetch_array($hostquery)) {
		printf("<tr align=center><td><a href='hosts.php?action=hostlookup&host_id=%s'>%s</a></td></tr>", $myhost["host_id"], $myhost["host_name"]);
	}
	echo "</table></td><td><table border=1 width=100%>\n";
	$hostgroupquery = mysql_query("SELECT DISTINCT hostgroups.hostgroup_name, hostgroups.hostgroup_id FROM hostgroups, services WHERE services.service_id='$service_id' AND hostgroups.hostgroup_id=services.hostgroup_id ORDER BY hostgroups.hostgroup_name");
	while ($mygroup=mysql_fetch_array($hostgroupquery)) {
		printf("<tr align=center><td><a href='hostgroups.php?hostgroup_id=%s'>%s</a></td></tr>", $mygroup["hostgroup_id"], $mygroup["hostgroup_name"]);
	}
	echo "</table></td></tr>\n";
}

?>
</td></tr>

</table>