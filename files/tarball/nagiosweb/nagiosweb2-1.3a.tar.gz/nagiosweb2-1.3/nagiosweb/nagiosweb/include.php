<?php

// Function to output radio boxes and determine if any are selected
function radio_button_resolver($listname, $listarray, $selected, $defaultresult) {
	if (is_null($selected)) {
		$selected=$defaultresult;
		$buttonresult=$defaultresult;
	}
	foreach($listarray as $listvalue) {
		if($selected==$listvalue) {
			printf('<input type="radio" name="%s" value="%s" checked>%s', $listname, $listvalue, $listvalue);
			$buttonresult=$listvalue;
		} else {
			printf('<input type="radio" name="%s" value="%s">%s', $listname, $listvalue, $listvalue);
		}
		echo "\n";
	}
	return $buttonresult;
}  // End Function


// Function to build check box values
function checkbox_values($listname, $listarray) {
$listresult='';
	foreach($listarray as $listvalue) {
		$listcheck=sprintf('%s_%s', $listname, str_replace(' ', '', $listvalue));
		global $$listcheck;
		if(isset($$listcheck)) {
			$listresult .= sprintf(", %s", $listvalue);
		}
	}

	if (stristr(substr($listresult, 0, 2),",")) {
		$listresult=substr($listresult, 2);
	}
	return $listresult;
} // End Function

// Function to output check boxes and determine if any are selected
function checkbox_resolver($listname, $listarray, $selected, $defaultresult) {
$selectedarray=explode(", ", $selected);
foreach($selectedarray as $selectedvalue) {
	$selectedcheck=sprintf('%s_%s', $listname, str_replace(' ', '', $selectedvalue));
	$$selectedcheck="true";
	}

$listresult='';
$checkarray=array();
	foreach($listarray as $listvalue) {
		$listcheck=sprintf('%s_%s', $listname, str_replace(' ', '', $listvalue));
//		global $$listcheck;
		if($$listcheck=="true") {
			array_push($checkarray, 'CHECKED');
			$listresult .= sprintf(", %s", $listvalue);
		} else {
			array_push($checkarray, 'a');
		}
		
	}

	reset($checkarray);
	reset($defaultresult);
	if ($listresult=='') {
		foreach($defaultresult as $checkvalue) {
			if ($key1=array_search($checkvalue, $listarray, false)) {
				$checkarray[$key1]="CHECKED";
				$listresult .= sprintf(", %s", $checkvalue);
			}
			if ($key1=='0') {
				$checkarray[$key1]="CHECKED";
				$listresult .= sprintf(", %s", $checkvalue);
			}
		}
	}

	reset($checkarray);
	foreach($listarray as $listvalue) {
	printf('<input type="checkbox" name="%s_%s" value="true" %s>%s&nbsp;&nbsp;', $listname, str_replace(' ', '', $listvalue), current($checkarray), $listvalue);
	next($checkarray);
	}
	
	if (stristr(substr($listresult, 0, 2),",")) {
		$listresult=substr($listresult, 2);
	}
	return $listresult;
}  // End Function

// Function to display dropdown box and determine which one was selected
function dropdown_resolver ($listname, $value, $display, $selected, $tablename) {
	$query = sprintf('SELECT %s, %s FROM %s ORDER BY %s', $value, $display, $tablename, $display);
	$query = mysql_query($query);
	printf('<select name="%s">', $listname);
	echo '<option value="" selected></option>\n';
	while ($curritem=mysql_fetch_array($query)) {
		if ($selected == $curritem[$value]) {
			$checked='selected';
			} else {
			$checked='';
			}			
		printf("<option value=\"%s\" %s>%s</option>\n", $curritem[$value], $checked, $curritem[$display]);
	}
	echo '</select>';

} // End Function

function list_resolver ($listname, $value, $display, $selected, $tablename) {
	printf('<select name="%s[]" multiple size=6>', $listname);
	$query = sprintf('SELECT %s, %s FROM %s ORDER BY %s', $value, $display, $tablename, $display);
	$query = mysql_query($query);
	while ($curritem=mysql_fetch_array($query)) {
		printf("<option value=\"%s\" %s>%s</option>\n", $curritem[$value], $checked, $curritem[$display]);
	}
	echo "</select>\n";
	print_r($selected);
}

function textbox_resolver ($attribute) {
	global $$attribute;
	$value = $$attribute;
	printf('<br><font color=red>%s &nbsp;&nbsp;=&nbsp;&nbsp; </font><input type="text" name="%s" value="%s"><br>', $attribute, $attribute, $value);
}

?>