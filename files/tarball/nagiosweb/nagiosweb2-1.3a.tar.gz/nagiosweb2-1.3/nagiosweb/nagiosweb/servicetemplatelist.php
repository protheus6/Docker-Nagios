<?php
//include("include.php");
include("dbconfig.php");

?>
<center><a href="servicetemplates.php">Add Service Template</a></center><br>
<table align="center" border="1" cellpadding="2" cellspacing="0" width="700">
<tr align="center"><td><b>Service Description</b></td><td><b>Check Period</b></td><td><b>Notify Period</b></td></tr>
<?
$servicequery = mysql_query("SELECT servicetemplate_id, service_description, check_period, notification_period FROM servicetemplates ORDER BY service_description");
while ($myservice = mysql_fetch_array($servicequery)) {
	$check_period=$myservice["check_period"];
	$checkq=mysql_query("SELECT timeperiod_name FROM timeperiods WHERE timeperiod_id='$check_period'");
	$check_period=mysql_result($checkq, 0);
	$notify_period=$myservice["notification_period"];
	$notifyq=mysql_query("SELECT timeperiod_name FROM timeperiods WHERE timeperiod_id='$notify_period'");
	$notify_period=mysql_result($notifyq, 0);
	printf('<tr valign=top><td><a href="servicetemplates.php?action=servicelookup&servicetemplate_id=%s">%s</a></td><td>%s</td><td>%s</td>', $myservice["servicetemplate_id"], $myservice["service_description"], $check_period, $notify_period);
	echo "</td></tr>\n";
}

?>
</td></tr>

</table>