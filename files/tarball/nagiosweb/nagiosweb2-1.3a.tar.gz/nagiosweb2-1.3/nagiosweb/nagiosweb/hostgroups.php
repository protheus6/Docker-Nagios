<?php
include("include.php");
include("dbconfig.php");

switch($action) {
	
	case 'Return to Host Groups':
	header("Location:hostgrouplist.php");
	break;
	
}

if ($delete) {
	$deletequery=mysql_query("DELETE FROM hostgroups WHERE hostgroup_id='$hostgroup_id'");
	$deletememquery=mysql_query("DELETE FROM hostgroup_members WHERE hostgroup_id='$hostgroup_id'");
	$deleteservicesquery=mysql_query("DELETE FROM services WHERE hostgroup_id='$hostgroup_id'");
	$deletecontactsquery=mysql_query("DELETE FROM hostgroup_contactgroups WHERE hostgroup_id='$hostgroup_id'");
	header("Location:hostgrouplist.php");
}

if ($service_id) {
	$deletequery=mysql_query("DELETE FROM hostgroup_services WHERE service_id='$service_id' AND hostgroup_id='$hostgroup_id'");
	header("Location:hostgroups.php?hostgroup_id=$hostgroup_id&hostgroup_name=$hostgroup_name");
}

if ($AddService  && (count($contactgroup_id)>0)) {
	foreach($contactgroup_id as $cg_id) {
		$deletequery=mysql_query("INSERT INTO hostgroup_services SET service_id='$service_id_add', hostgroup_id='$hostgroup_id', contactgroup_id='$cg_id'");
	}
	header("Location:hostgroups.php?hostgroup_id=$hostgroup_id&hostgroup_name=$hostgroup_name");
}

if ($ChangeHost) {
	if (count($member_host_id_remove)>0) {
		foreach($member_host_id_remove as $host_id) {
			$deletequery=mysql_query("DELETE FROM hostgroup_members WHERE host_id='$host_id' AND hostgroup_id='$hostgroup_id'");
		}
	}
	if (count($member_host_id_add)>0) {
		foreach($member_host_id_add as $host_id) {
			$deletequery=mysql_query("INSERT INTO hostgroup_members SET host_id='$host_id', hostgroup_id='$hostgroup_id'");
		}
	}
	header("Location:hostgroups.php?hostgroup_id=$hostgroup_id&hostgroup_name=$hostgroup_name");
}


if ($ChangeGroup) {
	if (count($member_contact_id_remove)>0) {
		foreach($member_contact_id_remove as $contactgroup_id) {
			$deletequery=mysql_query("DELETE FROM hostgroup_contactgroups WHERE contactgroup_id='$contactgroup_id' AND hostgroup_id='$hostgroup_id'");
		}
	}
	if (count($member_contact_id_add)>0) {
		foreach($member_contact_id_add as $contactgroup_id) {
			$deletequery=mysql_query("INSERT INTO hostgroup_contactgroups SET contactgroup_id='$contactgroup_id', hostgroup_id='$hostgroup_id'");
		}
	}
	header("Location:hostgroups.php?hostgroup_id=$hostgroup_id&hostgroup_name=$hostgroup_name");
}


$hostgroupnamequery=mysql_query("SELECT hostgroup_name FROM hostgroups WHERE hostgroup_id='$hostgroup_id'");
$hostgroup_name=mysql_result($hostgroupnamequery, 0);
?>
<html>
<head>
<title>Host Group Membership</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<div align="center"><b><font size="5">Host Group <?php echo $hostgroup_name?></font> <p>
  </b></div>
<form action="hostgroups.php" method="post" name="hostgroupform">
<center>
<input type="submit" name="delete" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;
<input type=submit name=action value="Return to Host Groups">
</center><br>

<input type="hidden" name="hostgroup_id" value="<? echo $hostgroup_id?>">
<input type="hidden" name="hostgroup_name" value="<? echo $hostgroup_name?>">
<table align="center">
<tr align="center">
    <td valign="top"><div align="center"><b>Member Hosts 
        </b> </div>
      <table align="center" border="1">
    <tr> 
    <tr> 
      <td><b>Member Hosts</b></td>
      <td></td>
      <td><b>Available Hosts</b></td>
    </tr>
    <?
$hostquery=mysql_query("SELECT * FROM hosts ORDER BY host_name");
$members = array();
$nonmembers = array();
while ($myhost=mysql_fetch_array($hostquery)) {
	$host_id=$myhost["host_id"];
	$hostcheck=mysql_query("SELECT * FROM hostgroup_members WHERE hostgroup_id='$hostgroup_id' AND host_id='$host_id'");
	if (mysql_num_rows($hostcheck) > 0) {
		$members[$host_id] = $myhost["host_name"];
		} else {
		$nonmembers[$host_id] = $myhost["host_name"];
		}
	}
	echo '<tr align=center><td valign="top" align="center"><select name="member_host_id_remove[]" size="6" multiple>';
foreach($members as $host_id => $host_name) {
	printf('<option value="%s">%s</option><br>', $host_id, $host_name);
	echo "\n";
	}
	echo '</select></td><td><input type="submit" name="ChangeHost" value="<-->"></td><td valign="top"><select name="member_host_id_add[]" size="6" multiple>';

foreach($nonmembers as $host_id => $host_name) {
	printf('<option value="%s">%s</option><br>', $host_id, $host_name);
	echo "\n";
	}
	echo '</select></td></tr>';
	

?>
  </table>
   
	<br><center>
        <div align="center"><b>Host Group Services</b></div>
	  <table align="center" border="1">
		<tr> 
		<tr> 
		  
		<td><b>Service</b></td>
		<td><b>Check Time</b></td>
		<td><b>Notify Time</b></td>
		  
		<td><b>Contact Group(s)</b></td>
			  <td>&nbsp;&nbsp;</td>
		</tr>
	<?
	$servicequery=mysql_query("SELECT service_id, service_description, check_period, notification_period FROM services WHERE hostgroup_id='$hostgroup_id' ORDER BY service_description");
	while ($service=mysql_fetch_array($servicequery)) {
		$notq=sprintf("SELECT timeperiod_name FROM timeperiods WHERE timeperiod_id='%s'", $service["notification_period"]);
		$notq=mysql_query($notq);
		$notification_period=mysql_result($notq, 0);
		$checkq=sprintf("SELECT timeperiod_name FROM timeperiods WHERE timeperiod_id='%s'", $service["check_period"]);
		$checkq=mysql_query($checkq);
		$check_period=mysql_result($checkq, 0);
		printf('<tr><td>%s</td><td>%s</td><td>%s</td><td>', $service["service_description"], $check_period, $notification_period);
		$service_id=$service["service_id"];
		$cgquery=mysql_query("SELECT contactgroups.contactgroup_name FROM contactgroups, service_contactgroups WHERE service_contactgroups.service_id='$service_id' AND contactgroups.contactgroup_id=service_contactgroups.contactgroup_id");
		while ($mycg=mysql_fetch_array($cgquery)) {
			printf('%s<br>', $mycg["contactgroup_name"]);
		}
		printf('</td><td><a href="services.php?&hostgroup_id=%s&service_id=%s&action=servicelookup">Edit</a>&nbsp;<a href="services.php?&hostgroup_id=%s&service_id=%s&action=Delete">Delete</a></tr>', $hostgroup_id, $service["service_id"], $hostgroup_id, $service["service_id"]);
	}
	?>
	</table>
	<?
		printf('<br><a href="services.php?&hostgroup_id=%s">Add Service to Host Group</a>', $hostgroup_id);
	?>
	</td></tr></table>



	</td>
  </tr></table>
<center>
    <p>
<center>
<input type="submit" name="delete" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;
<input type=submit name=action value="Return to Host Groups">
</form>
