<?php
//include("include.php");
include("dbconfig.php");
//include("top.php");

?>
<center><a href="checkcommands.php">Add New Check Command</a></center><br>

<table align="center" border="1" cellpadding="2" cellspacing="0">
<tr align="center"><td width=150><b>Check Command Name</b></td><td width=150><b>Check Command Line</b></td></tr>
<?
$commquery=mysql_query("SELECT * FROM command ORDER BY command_name");
while ($mycc=mysql_fetch_array($commquery)) {
	printf('<tr><td><a href="checkcommands.php?action=cclookup&command_id=%s">%s</a></td><td>%s</td></tr></a>', $mycc["command_id"], $mycc["command_name"], $mycc["command_line"]);
}
?>
</table>