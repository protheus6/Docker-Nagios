<?php
include("include.php");
include("dbconfig.php");

switch($action) {
	
	case 'Return to Service Groups':
	header("Location:servicegrouplist.php");
	break;
	
}

if ($delete) {
	$deletequery=mysql_query("DELETE FROM servicegroups WHERE servicegroup_id='$servicegroup_id'");
	$deletememquery=mysql_query("DELETE FROM servicegroup_members WHERE servicegroup_id='$servicegroup_id'");
//	$deleteservicesquery=mysql_query("DELETE FROM services WHERE servicegroup_id='$servicegroup_id'");
//	$deletecontactsquery=mysql_query("DELETE FROM servicegroup_contactgroups WHERE servicegroup_id='$servicegroup_id'");
	header("Location:servicegrouplist.php");
}

//if ($service_id) {
//	$deletequery=mysql_query("DELETE FROM servicegroup_services WHERE service_id='$service_id' AND servicegroup_id='$servicegroup_id'");
//	header("Location:servicegroups.php?servicegroup_id=$servicegroup_id&servicegroup_name=$servicegroup_name");
//}

//if ($AddService  && (count($contactgroup_id)>0)) {
//	foreach($contactgroup_id as $cg_id) {
//		$deletequery=mysql_query("INSERT INTO servicegroup_services SET service_id='$service_id_add', servicegroup_id='$servicegroup_id', contactgroup_id='$cg_id'");
//	}
//	header("Location:servicegroups.php?servicegroup_id=$servicegroup_id&servicegroup_name=$servicegroup_name");
//}

if ($ChangeService) {
	if (count($member_service_id_remove)>0) {
		foreach($member_service_id_remove as $service_id) {
			$deletequery=mysql_query("DELETE FROM servicegroup_members WHERE service_id='$service_id' AND servicegroup_id='$servicegroup_id'");
		}
	}
	if (count($member_service_id_add)>0) {
		foreach($member_service_id_add as $service_id) {
			$deletequery=mysql_query("INSERT INTO servicegroup_members SET service_id='$service_id', servicegroup_id='$servicegroup_id'");
		}
	}
	header("Location:servicegroups.php?servicegroup_id=$servicegroup_id&servicegroup_name=$servicegroup_name");
}


//if ($ChangeGroup) {
//	if (count($member_contact_id_remove)>0) {
//		foreach($member_contact_id_remove as $contactgroup_id) {
//			$deletequery=mysql_query("DELETE FROM servicegroup_contactgroups WHERE contactgroup_id='$contactgroup_id' AND servicegroup_id='$servicegroup_id'");
//		}
//	}
//	if (count($member_contact_id_add)>0) {
//		foreach($member_contact_id_add as $contactgroup_id) {
//			$deletequery=mysql_query("INSERT INTO servicegroup_contactgroups SET contactgroup_id='$contactgroup_id', servicegroup_id='$servicegroup_id'");
//		}
//	}
//	header("Location:servicegroups.php?servicegroup_id=$servicegroup_id&servicegroup_name=$servicegroup_name");
//}


$servicegroupnamequery=mysql_query("SELECT servicegroup_name FROM servicegroups WHERE servicegroup_id='$servicegroup_id'");
$servicegroup_name=mysql_result($servicegroupnamequery, 0);
?>
<html>
<head>
<title>Service Group Membership</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<div align="center"><b><font size="5">Service Group <?php echo $servicegroup_name?></font> <p>
  </b></div>
<form action="servicegroups.php" method="post" name="servicegroupform">
<center>
<input type="submit" name="delete" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;
<input type=submit name=action value="Return to Service Groups">
</center><br>

<input type="hidden" name="servicegroup_id" value="<? echo $servicegroup_id?>">
<input type="hidden" name="servicegroup_name" value="<? echo $servicegroup_name?>">
<table align="center">
<tr align="center">
    <td valign="top"><div align="center"> </div>
      <table align="center" border="1">
    <tr> 
    <tr> 
      <td><b>Member Services</b></td>
      <td></td>
      <td><b>Available Services</b></td>
    </tr>
    <?
//$hostquery=mysql_query("SELECT services.*, hostgroups.hostgroup_name FROM services, hostgroups WHERE hostgroups.hostgroup_id = services.hostgroup_id ORDER BY hostgroups.hostgroup_name, services.service_description");
$hostquery=mysql_query("SELECT * FROM services ORDER BY services.service_description");
$members = array();
$nonmembers = array();
while ($myhost=mysql_fetch_array($hostquery)) {
	extract($myhost);
	if ($host_id=='0'){
		$display_name="(HostGroup ". mysql_result(mysql_query("SELECT hostgroup_name FROM hostgroups WHERE hostgroup_id='$hostgroup_id'"), 0).")";
	} else {
		$display_name="(Host ". mysql_result(mysql_query("SELECT host_name FROM hosts WHERE host_id='$host_id'"), 0). ")";
	}
	$hostcheck=mysql_query("SELECT * FROM servicegroup_members WHERE servicegroup_id='$servicegroup_id' AND service_id='$service_id'");
	if (mysql_num_rows($hostcheck) > 0) {
		$members[$service_id] = $service_description . " " . $display_name;
		} else {
		$nonmembers[$service_id] = $service_description . " " . $display_name;
		}
	}
	echo '<tr align=center><td valign="top" align="center"><select name="member_service_id_remove[]" size="6" multiple>';
foreach($members as $service_id => $service_description) {
	printf('<option value="%s">%s</option><br>', $service_id, $service_description);
	echo "\n";
	}
	echo '</select></td><td><input type="submit" name="ChangeService" value="<-->"></td><td valign="top"><select name="member_service_id_add[]" size="6" multiple>';

foreach($nonmembers as $service_id => $service_description) {
	printf('<option value="%s">%s</option><br>', $service_id, $service_description);
	echo "\n";
	}
	echo '</select></td></tr>';
	

?>
  </table>
   
<!--	<br><center>
        <div align="center"><b>Host Group Services</b></div>
	  <table align="center" border="1">
		<tr> 
		<tr> 
		  
		<td><b>Service</b></td>
		<td><b>Check Time</b></td>
		<td><b>Notify Time</b></td>
		  
		<td><b>Contact Group(s)</b></td>
			  <td>&nbsp;&nbsp;</td>
		</tr>
	<?
	$servicequery=mysql_query("SELECT service_id, service_description, check_period, notification_period FROM services WHERE servicegroup_id='$servicegroup_id' ORDER BY service_description");
	while ($service=mysql_fetch_array($servicequery)) {
		$notq=sprintf("SELECT timeperiod_name FROM timeperiods WHERE timeperiod_id='%s'", $service["notification_period"]);
		$notq=mysql_query($notq);
		$notification_period=mysql_result($notq, 0);
		$checkq=sprintf("SELECT timeperiod_name FROM timeperiods WHERE timeperiod_id='%s'", $service["check_period"]);
		$checkq=mysql_query($checkq);
		$check_period=mysql_result($checkq, 0);
		printf('<tr><td>%s</td><td>%s</td><td>%s</td><td>', $service["service_description"], $check_period, $notification_period);
		$service_id=$service["service_id"];
		$cgquery=mysql_query("SELECT contactgroups.contactgroup_name FROM contactgroups, service_contactgroups WHERE service_contactgroups.service_id='$service_id' AND contactgroups.contactgroup_id=service_contactgroups.contactgroup_id");
		while ($mycg=mysql_fetch_array($cgquery)) {
			printf('%s<br>', $mycg["contactgroup_name"]);
		}
		printf('</td><td><a href="services.php?&servicegroup_id=%s&service_id=%s&action=servicelookup">Edit</a>&nbsp;<a href="services.php?&servicegroup_id=%s&service_id=%s&action=Delete">Delete</a></tr>', $servicegroup_id, $service["service_id"], $servicegroup_id, $service["service_id"]);
	}
	?>
	</table>
	<?
		printf('<br><a href="services.php?&servicegroup_id=%s">Add Service to Service Group</a>', $servicegroup_id);
	?>
	</td></tr></table>



	</td>
  </tr></table>-->
<br>
<input type="submit" name="delete" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;
<input type=submit name=action value="Return to Service Groups">
</form>
