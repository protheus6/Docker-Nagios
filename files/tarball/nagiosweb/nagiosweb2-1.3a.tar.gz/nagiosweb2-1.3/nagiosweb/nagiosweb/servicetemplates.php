<?php
include("include.php");
include("dbconfig.php");


$notification_options_array=array('OK', 'Warn', 'Unkn', 'Crit');
$notification_options_default_array=array('OK', 'Crit');
$stalking_options_array=array('OK', 'Warn', 'Unkn', 'Crit');
$stalking_options_default_array=array();

switch($action) {

	case 'Goto Service Templates':
	header("Location:servicetemplatelist.php");
	break;
		
	case AddService:
	$notification_options = checkbox_values("notification_options", $notification_options_array);
	$stalking_options = checkbox_values("stalking_options", $stalking_options_array);
	$fields = mysql_list_fields($nagiosweb, "servicetemplates");
	$columns = mysql_num_fields($fields);
	for ($i = 1; $i < $columns; $i++) {
		$tempname = mysql_field_name($fields, $i);
		$query = sprintf("%s, %s = '%s'", $query, $tempname, $$tempname);
	}

	if (stristr(substr($query, 0, 2),",")) {
		$query=substr($query, 2);
	}

	$query = sprintf("INSERT INTO servicetemplates SET %s", $query);
	$queryresult = mysql_query($query);
	$servicetemplate_id=mysql_insert_id();
	header("Location:servicetemplates.php?action=servicelookup&servicetemplate_id=$servicetemplate_id");
	break;

	case servicelookup:
	$fields = mysql_list_fields($nagiosweb, "servicetemplates");
	$columns = mysql_num_fields($fields);
	$myquery = mysql_query("SELECT servicetemplates.* FROM servicetemplates WHERE servicetemplate_id='$servicetemplate_id'");
	$myitem = mysql_fetch_array($myquery);
	for ($i = 0; $i < $columns; $i++) {
		$tempname = mysql_field_name($fields, $i);
		$$tempname = $myitem[$tempname];
	}
//	if ($host_id>0) {
//		$host_name=$myitem["host_name"];
//	} else {
//		$host_name=$myitem["hostgroup_name"];
//	}
	break;

	case Delete:
	echo "<center><b><font color=red>Are you sure you want to delete this service template?</font></b></center>";
	$fields = mysql_list_fields($nagiosweb, "servicetemplates");
	$columns = mysql_num_fields($fields);
	$myquery = mysql_query("SELECT * FROM servicetemplates WHERE servicetemplate_id='$servicetemplate_id'");
	$myitem = mysql_fetch_array($myquery);
	for ($i = 0; $i < $columns; $i++) {
		$tempname = mysql_field_name($fields, $i);
		$$tempname = $myitem[$tempname];
	}
	break;

	case confirmed:
	$deletequery = mysql_query("DELETE FROM servicetemplates WHERE servicetemplate_id='$servicetemplate_id'");
//	$hgdelquery = mysql_query("DELETE FROM hostgroup_services WHERE servicetemplate_id='$servicetemplate_id'");
//	$cgdelquery = mysql_query("DELETE FROM service_contactgroups WHERE servicetemplate_id='$servicetemplate_id'");
//	$depdelquery = mysql_query("DELETE FROM servicedependency WHERE servicetemplate_id='$servicetemplate_id' OR dependent_servicetemplate_id='$servicetemplate_id'");
//	if($host_id<>0 && $hostgroup_id=='0') {
//		header("Location:hosts.php?action=hostlookup&host_id=$host_id");
//	} else {
//		header("Location:hostgroups.php?hostgroup_id=$hostgroup_id");
//	}
	header("Location:servicetemplatelist.php");
	break;

	case servicesave:
	$notification_options = checkbox_values("notification_options", $notification_options_array);
	$stalking_options = checkbox_values("stalking_options", $stalking_options_array);
	$fields = mysql_list_fields($nagiosweb, "servicetemplates");
	$columns = mysql_num_fields($fields);
	for ($i = 0; $i < $columns; $i++) {
		$tempname = mysql_field_name($fields, $i);
		$query = sprintf("%s, %s = '%s'", $query, $tempname, $$tempname);
	}

	if (stristr(substr($query, 0, 2),",")) {
		$query=substr($query, 2);
	}

	$query = sprintf("UPDATE servicetemplates SET %s WHERE servicetemplate_id = '$servicetemplate_id'", $query);
	$queryresult = mysql_query($query);
	header("Location:servicetemplates.php?action=servicelookup&servicetemplate_id=$servicetemplate_id");
	break;

	case Duplicate:
	$fields = mysql_list_fields($nagiosweb, "servicetemplates");
	$columns = mysql_num_fields($fields);
	$myquery = mysql_query("SELECT * FROM servicetemplates WHERE servicetemplate_id='$servicetemplate_id'");
	$myitem = mysql_fetch_array($myquery);
	for ($i = 0; $i < $columns; $i++) {
		$tempname = mysql_field_name($fields, $i);
		$$tempname = $myitem[$tempname];
	}
	$servicetemplate_id='';
	$service_description='';
	break;

	default:
	// Set Defaults because we're adding a new service
	$check_period='1';  // 24x7 timeperiod
	$max_check_attempts='2';
	$normal_check_interval='5';
	$retry_check_interval='5';
	$notification_period='1'; // 24x7 timeperiod
	$notification_interval='30';
	break;
}

//print_r($_POST);
?>
<form action="servicetemplates.php" method="post">
<input type="hidden" name="servicetemplate_id" value="<? echo $servicetemplate_id ?>">
<center>
<?
if ($action == 'servicelookup') {
	echo '<input type="hidden" name="action" value="servicesave">';
	echo '<input type="submit" name="submit" value="Submit Info">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Goto Service Templates">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;';
} elseif ($action == 'Delete') {
	echo '<input type="hidden" name="action" value="confirmed">';
	echo '<input type="submit" name="submit" value="Yes Delete It!">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="submit" value="Goto Service Templates">&nbsp;&nbsp;&nbsp;&nbsp;';
} else {
	echo '<input type="hidden" name="action" value="AddService">';
	echo '<input type="submit" name="submit" value="Add Service Template">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="submit" value="Goto Service Templates">&nbsp;&nbsp;&nbsp;&nbsp;';
}

?>

</center><br>

<table align="center" border="1" cellspacing="2" cellpadding="0" width="800">
<tr><td colspan="4" align="center"><b>Service Template Details</b></td></tr>
<tr>
      <td width="200"><strong>Service Description:</strong></td>
      <td width="200"><input type="text" name="service_description" value="<? echo $service_description ?>"></td>
      <td width="200">&nbsp;</td>
	  <td width="200">&nbsp;</td>
	  </tr>
	  <tr>
      <td width="200"><strong>Check Command:</strong></td>
      <td>
<?
dropdown_resolver("check_command", "command_id", "command_name", $check_command, "command");

// This is a hack that needs to be cleaned up
$checkquery=mysql_query("SELECT command_line, help_text FROM command WHERE command_id='$check_command'");
//if (mysql_num_rows($checkquery)>0) {
//	$command_line=mysql_result($checkquery, 0);
if(mysql_num_rows($checkquery)>0)
{
	extract(mysql_fetch_array($checkquery));
}

?>
</td></tr>
<td width="200"><strong>Check Command Line<br></strong><i><font size="2">(Submit to Refresh)</font></i>:</td>
<td colspan="3"><? echo $command_line ?></td></tr>
<td width="200" valign=top><strong>Check Command Help:</td>
<td colspan="3"><textarea name="help_text" cols="65" rows="6"><? echo $help_text ?></textarea></td></tr>
<tr>
      <td><strong>Check Command Args<br>
        (use : to separate args):</strong></td>
      <td colspan="3"><textarea name="command_args" cols="50" rows="4"><? echo $command_args ?></textarea>
        </td>
    </tr>
<tr>
      <td><strong>Active Checks Enabled:</strong></td>
      <td>
<?
$active_checks_enabled_array=array('Yes', 'No');
radio_button_resolver('active_checks_enabled', $active_checks_enabled_array, $active_checks_enabled, 'Yes');
?>
</td>
      <td><strong>Check Period:</strong></td>
      <td>
<?
dropdown_resolver("check_period", "timeperiod_id", "alias", $check_period, "timeperiods");
?>
</td>
</tr>
<tr>
      <td><strong>Passive Checks Enabled:</strong></td>
      <td>
<?
$passive_checks_enabled_array=array('Yes', 'No');
radio_button_resolver('passive_checks_enabled', $passive_checks_enabled_array, $passive_checks_enabled, 'Yes');
?>
</td>
      <td><strong>Max Check Attempts:</strong></td>
      <td><input name="max_check_attempts" type="text" value="<? echo $max_check_attempts ?>" size="4"></td>
<tr><td colspan="2">&nbsp;</td>
      <td><strong>Normal Check Interval:</strong></td>
      <td><input name="normal_check_interval" type="text" value="<? echo $normal_check_interval ?>" size="4">
        minutes </td>
    </tr>
<tr><td colspan="2">&nbsp;</td>
      <td><strong>Retry Check Interval:</strong></td>
      <td><input name="retry_check_interval" type="text" value="<? echo $retry_check_interval ?>" size="4">
        minutes </td>
    </tr>
<tr>
      <td><strong>Notifications Enabled:</strong></td>
      <td>
<?
$notifications_enabled_array=array('Yes', 'No');
radio_button_resolver('notifications_enabled', $notifications_enabled_array, $notifications_enabled, 'Yes');
?>
</td>
      <td><strong>Notify On:</strong></td>
      <td>
<?
$notification_options = checkbox_resolver('notification_options', $notification_options_array, $notification_options, $notification_options_default_array);
?>
</td></tr>
<tr><td colspan="2">&nbsp;</td>
      <td><strong>Notification Period:</strong></td>
      <td>
<?
dropdown_resolver("notification_period", "timeperiod_id", "alias", $notification_period, "timeperiods");
?>
</td></tr>
<tr><td colspan="2">&nbsp;</td>
      <td><strong>Notification Interval:</strong></td>
      <td><input name="notification_interval" type="text" value="<? echo $notification_interval ?>" size="4">
        minutes </td>
<tr>
      <td><strong>Parallelize Check:</strong></td>
      <td>
<?
$parallelize_check_array=array('Yes', 'No');
radio_button_resolver('parallelize_check', $parallelize_check_array, $parallelize_check, 'Yes');
?>
</td>
<td><strong>Obsess Over Service:</strong></td>
      <td>
<?
$obsess_over_service_array=array('Yes', 'No');
radio_button_resolver('obsess_over_service', $obsess_over_service_array, $obsess_over_service, 'No');
?>
</td></tr>
<tr>
      <td><strong>Check Freshness:</strong></td>
      <td>
<?
$check_freshness_array=array('Yes', 'No');
radio_button_resolver('check_freshness', $check_freshness_array, $check_freshness, 'No');
?>
</td>
      <td><strong>Freshness Threshold:</strong></td>
      <td><input name="freshness_threshold" type="text" value="<? echo $freshness_threshold ?>" size="4"></td></tr>
<tr>
      <td><strong>Event Handler Enabled:</strong></td>
      <td>
<?
$event_handler_enabled_array=array('Yes', 'No');
radio_button_resolver('event_handler_enabled', $event_handler_enabled_array, $event_handler_enabled, 'No');
?>
</td>
      <td><strong>Event Handler:</strong></td>
      <td>
<?
dropdown_resolver("event_handler", "command_id", "command_name", $event_handler, "command");
?>
</td></tr>
<tr>
      <td><strong>Flap Detection Enabled:</strong></td>
      <td>
<?
$flap_detection_enabled_array=array('Yes', 'No');
radio_button_resolver('flap_detection_enabled', $flap_detection_enabled_array, $flap_detection_enabled, 'No');
?>
</td>
      <td><strong>Low Flap Threshold:</strong></td>
      <td><input name="low_flap_threshold" type="text" value="<? echo $low_flap_threshold ?>" size="4"></td></tr>
<tr><td colspan="2">&nbsp;</td>
      <td><strong>High Flap Threshold:</strong></td>
      <td><input name="high_flap_threshold" type="text" value="<? echo $high_flap_threshold ?>" size="4"></td></tr>
<tr>
      <td><strong>Process Perf Data:</strong></td>
      <td>
<?
$process_perf_data_array=array('Yes', 'No');
radio_button_resolver('process_perf_data', $process_perf_data_array, $process_perf_data, 'No');
?>
</td></tr>
<tr>
      <td><strong>Is Volatile:</strong></td>
      <td>
<?
$is_volatile_array=array('Yes', 'No');
radio_button_resolver('is_volatile', $is_volatile_array, $is_volatile, 'No');
?>
</td>
      <td><strong>Stalking Options:</strong></td>
      <td>
<?
$stalking_options = checkbox_resolver('stalking_options', $stalking_options_array, $stalking_options, $stalking_options_default_array);
?>
</td></tr>
<tr>
      <td><strong>Retain Status Info:</strong></td>
      <td>
<?
$retain_status_information_array=array('Yes', 'No');
radio_button_resolver('retain_status_information', $retain_status_information_array, $retain_status_information, 'Yes');
?>
</td>
      <td><strong>Retain Non-Status Info:</strong></td>
      <td>
<?
$retain_nonstatus_information_array=array('Yes', 'No');
radio_button_resolver('retain_nonstatus_information', $retain_nonstatus_information_array, $retain_nonstatus_information, 'Yes');
?>
</td></tr>
</table><br>

<br>
<center>
<?

if ($action == 'servicelookup') {
	echo '<input type="submit" name="submit" value="Submit Info">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Goto Service Templates">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;';
} elseif ($action == 'Delete') {
	echo '<input type="hidden" name="action" value="confirmed">';
	echo '<input type="submit" name="submit" value="Yes Delete It!">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Goto Service Templates">&nbsp;&nbsp;&nbsp;&nbsp;';
} else {
	echo '<input type="hidden" name="action" value="AddService">';
	echo '<input type="submit" name="submit" value="Add Service Template">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Goto Service Templates">&nbsp;&nbsp;&nbsp;&nbsp;';
}


?>
</center><br>

</form>




