<?php
include("include.php");
include("dbconfig.php");

$days_array=array('Sun', 'Mon', 'Tues', 'Wed', 'Thur', 'Fri', 'Sat');
$days_default_array=array();

if($add) {
	$days = checkbox_values("days", $days_array);
	$starttime = strftime("%T", strtotime($starttime));
	$duration=$duration*60;
	$name='Nagios Downtime Scheduler';
	$insertquery=mysql_query("INSERT INTO downtime SET days='$days', host_name='$host_name', starttime='$starttime', duration='$duration', fd='$fd', name='$name', comments='$comments', host_id='$host_id'");
	header("Location:hosts.php?action=hostlookup&host_id=$host_id");
} elseif ($update) {
	$days = checkbox_values("days", $days_array);
	$starttime = strftime("%T", strtotime($starttime));
	$duration=$duration*60;
	$name='Nagios Downtime Scheduler';
	$updatequery=mysql_query("UPDATE downtime SET days='$days', host_name='$host_name', starttime='$starttime', duration='$duration', fd='$fd', name='$name', comments='$comments', host_id='$host_id' WHERE downtime_id='$downtime_id'");
	header("Location:hosts.php?action=hostlookup&host_id=$host_id");
}

if ($downtime_id) {
	$fields = mysql_list_fields($nagiosweb, "downtime");
	$columns = mysql_num_fields($fields);
	$query=mysql_query("SELECT * FROM downtime WHERE downtime_id='$downtime_id'");
	$mydown = mysql_fetch_array($query);
	for ($i = 0; $i < $columns; $i++) {
		$tempname = mysql_field_name($fields, $i);
		$$tempname = $mydown[$tempname];
	}
}

printf('<center><b>%s Host Downtime</b></center><br>', $host_name);

?>

<form action="downtimehost.php" method="post">
<input type="hidden" name="host_id" value="<? echo $host_id ?>">
<input type="hidden" name="downtime_id" value="<? echo $downtime_id ?>">
<input type="hidden" name="host_name" value="<? echo $host_name ?>">

<table border="1" align="center">
<tr><td><b>Days:</b></td><td>
<?
$days = checkbox_resolver('days', $days_array, $days, $days_default_array);
?>
</td></tr>
<tr><td><b>Start Time:</b></td><td>
<input type=text name="starttime" value="<? echo $starttime ?>">
      Military Time</td>
  </tr>
<tr><td><b>Duration:</b></td><td>
<input type=text name="duration" value="<? echo $duration/60 ?>" size="10"> Minutes
</td></tr>
<tr><td><b>Fixed/Dynamic:</b></td><td>
<?
$fd_array=array('Dynamic', 'Fixed');
radio_button_resolver('fd', $fd_array, $fd, 'Dynamic');
?>
</td></tr>
<tr><td><b>Comments:</b></td><td>
<textarea name="comments" rows="4" cols="60"><? echo $comments ?></textarea>
</td></tr>
</table><br><center>
<?
if ($downtime_id) {
	echo '<input type="submit" name="update" value="Schedule Downtime"></center>';
} else {
	echo '<input type="submit" name="add" value="Schedule Downtime"></center>';
}
?>
</form>
