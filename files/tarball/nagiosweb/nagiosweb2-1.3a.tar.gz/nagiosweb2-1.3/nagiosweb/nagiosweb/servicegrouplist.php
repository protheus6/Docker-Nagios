<?php
//include("include.php");
include("dbconfig.php");

if ($servicegroup_name) {
	$insertquery=mysql_query("INSERT INTO servicegroups SET servicegroup_name='$servicegroup_name'");
	$servicegroup_id=mysql_insert_id();
	header("Location:servicegroups.php?servicegroup_id=$servicegroup_id&servicegroup_name=$servicegroup_name");
}



?>
<center><form action="servicegrouplist.php" method="post">
<input type="text" name="servicegroup_name">&nbsp;&nbsp;<input type="submit" name="Addservicegroup" value="Add Service Group">
</form></center>
<table align="center" border="1" cellpadding="2" cellspacing="0" width="700">
  <tr align="center">
  	<td><strong>Service Group Name</strong></td>
    <td><strong>Members</strong></td>
  </tr>
<?
$sgquery = mysql_query("SELECT * FROM servicegroups ORDER BY servicegroup_name");
while ($myhg=mysql_fetch_array($sgquery)) {
	printf('<tr valign=top><td><a href="servicegroups.php?servicegroup_id=%s">%s</a></td><td><table border=1 width=100%%><tr>', $myhg["servicegroup_id"], $myhg["servicegroup_name"]);
	$servicegroup_id = $myhg["servicegroup_id"];
	$i=0;
//	$memberquery = mysql_query("SELECT hosts.host_id, hosts.host_name FROM hosts, servicegroup_members WHERE servicegroup_members.servicegroup_id='$servicegroup_id' and hosts.host_id = servicegroup_members.host_id ORDER BY hosts.host_name");
	$memberquery = mysql_query("SELECT services.service_id, services.service_description FROM services, servicegroup_members WHERE servicegroup_members.servicegroup_id='$servicegroup_id' and services.service_id = servicegroup_members.service_id ORDER BY services.service_description");
	while ($mymember=mysql_fetch_array($memberquery)) {
		if ($i>2) {
			echo '</tr><tr>';
			$i=0;
			}
		$i++;
		printf("<td align=center width=33%%><a href='services.php?action=servicelookup&service_id=%s'>%s</a></td>\n", $mymember["service_id"], $mymember["service_description"]);
	}
//	echo "</table></td></tr>";
//	echo "</table></td><td valign=top><table border=1 width=100>";
//	$servicequery = mysql_query("SELECT DISTINCT service_id, service_description FROM services WHERE servicegroup_id='$servicegroup_id'");
//	while ($myservice=mysql_fetch_array($servicequery)) {
//		printf("<tr align=center><td><a href='services.php?action=servicelookup&service_id=%s'>%s</a></td></tr>", $myservice["service_id"], $myservice["service_description"]);
//		} 
	echo "</table>";	
}
?>
</td></tr>

</table>

