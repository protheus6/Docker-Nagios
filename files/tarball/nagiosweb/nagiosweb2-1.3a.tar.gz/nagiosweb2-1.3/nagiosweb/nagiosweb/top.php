<table align="center"><tr><td>
<a href="hostlist.php">Hosts</a>
</td><td>&nbsp;|&nbsp;
<a href="hostgrouplist.php">Host Groups</a>
</td><td>&nbsp;|&nbsp;
<a href="servicelist.php">Services</a>
</td><td>&nbsp;|&nbsp;
<a href="contactlist.php">Contacts</a>
</td><td>&nbsp;|&nbsp;
<a href="contactgrouplist.php">Contact Groups</a>
</td><td>&nbsp;|&nbsp;
<a href="timeperiodlist.php">Time Periods</a>
</td><td>&nbsp;|&nbsp;
<a href="checkcommandlist.php">Check Commands</a>
</td><td>&nbsp;|&nbsp;
<a href="notifylist.php">Notification Commands</a>
</td><td>&nbsp;|&nbsp;
<a href="createtxt.php">Write Config</a>
</td></tr></table>
<br><br>