<?php

include("include.php");
include("dbconfig.php");

switch($action) {

	case "Return to Notifications":
	header("Location:notifylist.php");
	break;

	case commandsave:
	$updatequery=mysql_query("UPDATE notify SET command_name='$command_name', command_line='$command_line' WHERE command_id='$command_id'");
	header("Location:notifications.php?action=cclookup&command_id=$command_id");
	break;

	case Delete:
//	echo $command_id;
//	$usecount=0;
	$contactquery=mysql_query("SELECT contact_name FROM contacts WHERE host_notification_command_email='$command_id' OR host_notification_command_pager='$command_id' OR service_notification_command_email='$command_id' OR service_notification_command_pager='$command_id'");
	if (mysql_num_rows($contactquery)>0)
	{
//		$usecount=$usecount + mysql_num_rows($contactquery);
		printf('<center>These contacts use the %s check command, you will need to change them before you can delete it.<br><br>', $timeperiod_name);
		while ($mycontact=mysql_fetch_array($contactquery)) {
			printf('<center>Contact <font color=red>%s</font><br>', $mycontact["contact_name"]);
		}
		$action='cclookup';
		echo '<br>';
	} else {
		$delquery =mysql_query("DELETE FROM notify WHERE command_id='$command_id'");
		header("Location:notifylist.php");
	}
	break;

	case AddCommand:
	$insertquery=mysql_query("INSERT INTO notify SET command_name='$command_name', command_line='$command_line'");
	$command_id=mysql_insert_id();
	header("Location:notifications.php?action=cclookup&command_id=$command_id");
	break;

	case cclookup:
	$query=mysql_query("SELECT * FROM notify WHERE command_id='$command_id'");
	$mycc=mysql_fetch_array($query);
	$command_name=$mycc["command_name"];
	$command_line=$mycc["command_line"];
	$number_args=$mycc["number_args"];
	break;

}

?>

<form action="notifications.php" method="post">
<input type="hidden" name="command_id" value="<? echo $command_id ?>">
<input type="hidden" name="action" value="commandsave">

<center>
<?
if ($action == 'cclookup') {
	echo '<input type="submit" name="submit" value="Submit Info">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Return to Notifications">';
} else {
	echo '<input type="hidden" name="action" value="AddCommand">';
	echo '<input type="submit" name="submit" value="Add Notification Command">&nbsp;&nbsp;&nbsp;&nbsp;';
}
?>
</center><br>
<table align="center" border="1" cellspacing="2" cellpadding="0" width="600">
<tr><td colspan="2" align="center"><b>Notification Details</b></td></tr>
<tr>
    <td><strong>Notification Name:</strong></td>
    <td><input type=text name="command_name" value="<? echo $command_name ?>"></td></tr>
<tr>
    <td><strong>Command Line:</strong></td>
    <td><textarea name="command_line" cols=65 rows="5"><? echo $command_line ?></textarea></td></tr>
</table>
<center><br>
<?
if ($action == 'cclookup') {
	echo '<input type="submit" name="submit" value="Submit Info">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Return to Notifications">';
} else {
	echo '<input type="hidden" name="action" value="AddCommand">';
	echo '<input type="submit" name="submit" value="Add Notification Command">&nbsp;&nbsp;&nbsp;&nbsp;';
}
?>

</center><br>

	