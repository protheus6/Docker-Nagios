<?php

// Database connectivity
$nagiosweb='nagiosweb';
$db = mysql_connect("localhost", "mysql", "mysql");
mysql_select_db($nagiosweb);

// $prefix is the path to where nagios is installed
$prefix='/usr/local/nagios';
$etcprefix = $prefix . '/etc';

// Path to htdocs directory
$htdocsdir='/usr/local/apache2/htdocs';

// Full path to php binary, include php
$phppath='/usr/local/bin/php';

// Hostname of your nagios server i.e. nagios.yourname.com
$nagioshostname='nagios.guidehome.com';

// Administrator Contact Info
$adminname='Your Name';
$adminphone='Your Phone';
$adminemail='email@yourdomain.com';

// Attempt at removing global_variables requirement
//extract($_POST);

?>
