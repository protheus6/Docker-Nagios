<?php
//include("include.php");
include("dbconfig.php");
//include("top.php");

?>
<center><a href=timeperiods.php>Add New Time Period</a></center><br>

<table align="center" border="1" cellpadding="2" cellspacing="0">
<tr align="center"><td width=150><b>Time Period Name</b></td><td width="100"><b>Sunday</b></td><td width="100"><b>Monday</b></td><td width="100"><b>Tuesday</b></td><td width="100"><b>Wednesday</b></td><td width="100"><b>Thursday</b></td><td width="100"><b>Friday</b></td><td width="100"><b>Saturday</b></td></tr>
<?
$tpquery=mysql_query("SELECT * FROM timeperiods ORDER BY timeperiod_name");
while ($mytp=mysql_fetch_array($tpquery)) {
	printf('<tr><td><a href="timeperiods.php?action=tplookup&timeperiod_id=%s">%s</a></td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr></a>', $mytp["timeperiod_id"], $mytp["timeperiod_name"], $mytp["sunday"], $mytp["monday"], $mytp["tuesday"], $mytp["wednesday"], $mytp["thursday"], $mytp["friday"], $mytp["saturday"]);
}
?>
</table>