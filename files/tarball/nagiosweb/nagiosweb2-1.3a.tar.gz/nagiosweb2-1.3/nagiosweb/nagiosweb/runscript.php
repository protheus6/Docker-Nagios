<?

include("dbconfig.php");

function showtitle()
{
	echo'<body><center><b><font size=4>Implementing the Configuration is a 3 Step Process</font></b><br><br>';
	printf('<form action="%s" method="post">', $_SERVER['PHP_SELF']);
}

function revisiontitle()
{
	echo'<body><center><b><font size=4>Implementing the Configuration is a 3 Step Process</font></b><br><br>';
	printf('<form action="%s" method="post">', $_SERVER['PHP_SELF']);
}

function datadump ($table) {

//	$result .= "# Dump of $table \n";
//	$result .= "# Dump DATE : " . date("d-M-Y") ."\n\n";

	$squery = mysql_query("SHOW CREATE TABLE $table");
	$sresult = mysql_fetch_array($squery);

//	$result .= ereg_replace("\n","\\n",addslashes($sresult[1])) . "\n\n\n";
//	$result .= addslashes($sresult[1]) . ";\n\n\n";
	
	$result .= $sresult[1] . ";\n\n\n";

	$query = mysql_query("select * from $table");
	$num_fields = @mysql_num_fields($query);
	$numrow = mysql_num_rows($query);
	while ($row = mysql_fetch_array($query))
	{
		//	for ($i =0; $i<$numrow; $i++) {
		$result .= "INSERT INTO ".$table." VALUES(";
		for($j=0; $j<$num_fields; $j++) {
			$row[$j] = addslashes($row[$j]);
	//					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
			if (isset($row[$j])) $result .= "\"$row[$j]\"" ; else $result .= "\"\"";
			if ($j<($num_fields-1)) $result .= ",";
		}
		$result .= ");\n";
		//	}
	}
	return $result . "\n\n\n";
}


switch($action) {

	case 'restartprocess':
	//	header("Location:http://nagios.guidehome.com/nagios/cgi-bin/cmd.cgi?cmd_typ=13&cmd_mod=2");
	header("Location:/nagios/cgi-bin/cmd.cgi?cmd_typ=13&cmd_mod=2");
	break;

	default:
	showtitle();
	echo '1. Write Config &nbsp;&nbsp;&nbsp;&nbsp; 2. Verify Config &nbsp;&nbsp;&nbsp;&nbsp; 3. Restart Process<br><br>';
	echo '<input type=hidden name=action value="writeconfig">';
	echo '<input type=submit value="Write the Config Files"></form><hr>';
	echo '<b><font size=4><font color=red>Not working yet</font><br>Save a Copy of the Configuration</font></b><br><br>';
	printf('<form action="%s" method="post">', $_SERVER['PHP_SELF']);
	echo '<input type=hidden name=action value="savecopy">';
	echo '<input type=text name=copyname value="Enter name of Copy"><br><br>';
	echo '<input type=submit value="Save the Config"></form><hr>';
	echo '</form>';
	//	$restorequery=mysql_query('SHOW DATABASES');
	if (is_dir($etcprefix.'/dbbackups'))
	{
		echo '<b><font size=4><font color=red>Not working yet</font><br>Restore a Saved Configuration</font></b><br><br>';
		printf('<form action="%s" method="post">', $_SERVER['PHP_SELF']);
		echo '<input type=hidden name=action value="restorecopy">';
		echo '<select name=restorename><option value="">Select a Backup to Restore</option>';
		$path=$etcprefix.'/dbbackups';
		$dir_handle = opendir($path);
		while (false !== ($file = readdir($dir_handle)))
		{
			if ($file !== '.' and $file !== '..')
			{
				printf ('<option value="%s">%s</option>', $file, $file);
			}
		}
		echo '</select><br><br>';
		closedir($dir_handle);
		echo '<input type=submit value="Save the Config"></form><hr>';
		//		echo '<input type=text name=copyname value="Enter name of Copy"><br>';
		echo '</form>';
	}
	break;

	case 'restorecopy';
	echo '<center><b><font size=4><font color=red>Not working yet</font><br>This will overwrite your current NagiosWeb Db<br>Are you sure?</font></b><br><br>';
	printf('<form action="%s" method="post">', $_SERVER['PHP_SELF']);
	echo '<input type=hidden name=action value="restorecopyconfirmed">';
	printf ('<input type=hidden name=restorename value="%s">', $restorename);
	echo '<input type=submit value="Yes, Restore the Config"></form><hr>';
	break;

	case 'restorecopyconfirmed':
	$restoredb = 'test';
	mysql_selectdb($restoredb);
	if (is_file($etcprefix.'/dbbackups/'.$restorename))
	{
		$filename = $etcprefix.'/dbbackups/'.$restorename;
		$handle = fopen($filename, "r");
		$contents = fread($handle, filesize($filename));
		fclose($handle);
		$contents = str_replace(chr(10), " ", str_replace(chr(13), " ", $contents));
		$result=mysql_query($contents);
		echo mysql_result($result, 0)."\n\n";
		echo $contents;
	}
	echo '</center>';


	break;

	case 'savecopy':
	// Replace spaces in copyname
	$copyname=str_replace(' ', '_', $copyname);
	// Create dbbackup directory
	if (! is_dir($etcprefix.'/dbbackups'))
	{
		mkdir ($etcprefix.'/dbbackups');
		echo 'Created '.$etcprefix.'/dbbackups Directory';
	} else {
		echo $etcprefix.'/dbbackups already exists';
	}

	echo "<br><br>";

	// Create a directory for the backup, make sure it is a current directory
	if (is_file($etcprefix.'/dbbackups/'.$copyname))
	{
		echo $etcprefix.'/dbbackups/'.$copyname.' already exists';
		echo "<br><br>";
		echo "Please choose a name that doesn't already exist";

	} else {
		//		mkdir ($etcprefix.'/dbbackups/'.$copyname);
		//		echo 'Created '.$etcprefix.'/dbbackups/'.$copyname.' Directory';

		echo "<br><br>";

		//		$filename = tempnam($etcprefix.'/dbbackups', 'nagiosweb');
		$filename = $etcprefix.'/dbbackups/'.$copyname;

		$command=datadump("command");
		$contactgroup_members=datadump("contactgroup_members");
		$contactgroups=datadump("contactgroups");
		$contacts=datadump("contacts");
		$downtime=datadump("downtime");
		$host_contactgroups=datadump("host_contactgroups");
		$host_parents=datadump("host_parents");
		$hostdependency=datadump("hostdependency");
		$hostgroup_contactgroups=datadump("hostgroup_contactgroups");
		$hostgroup_members=datadump("hostgroup_members");
		$hostgroups=datadump("hostgroups");
		$hosts=datadump("hosts");
		$notify=datadump("notify");
		$service_contactgroups=datadump("service_contactgroups");
		$servicedependency=datadump("servicedependency");
		$services=datadump("services");
		$timeperiods=datadump("timeperiods");

		$content=$command.$contactgroup_members.$contactgroups.$contacts.$downtime.$host_contactgroups.$host_parents.$hostdependency.$hostgroup_contactgroups.$hostgroup_members.$hostgroups.$hosts.$notify.$service_contactgroups.$servicedependency.$services.$timeperiods;

		$handle=fopen($filename, w);
		fwrite($handle, $content);
		fclose($handle);
	}
	break;

	case 'writeconfig':
	showtitle();
	echo '<strike>Write Config</strike> &nbsp;&nbsp;&nbsp;&nbsp; 2. Verify Config &nbsp;&nbsp;&nbsp;&nbsp; 3. Restart Process<br><br>';
	echo '<input type=hidden name=action value="verifyconfig">';
	echo '<input type=submit value="Verify the Config Files"><br><br>';
	$xcommand = sprintf("%s %s/nagiosweb/createtxt.php", $phppath, $htdocsdir);
	exec($xcommand, $arlines, $returncode);
	if($returncode > 0)
	{
		//		echo 'There was an error writing the configuration files.  Call Josh 267-2427';
		printf('There was an error writing the configuration files.  Call %s at %s or send an e-mail to %s', $adminname, $adminphone, $adminemail);
	} else {
		echo '<table border="0" align="center">';
		foreach($arlines as $arvalues){
			echo "<tr><td>" . $arvalues . "</td></tr>";
		}
		echo '</table';
	}
	break;

	case 'verifyconfig':
	showtitle();
	echo '1. <strike>Write Config</strike> &nbsp;&nbsp;&nbsp;&nbsp; 2. <strike>Verify Config</strike> &nbsp;&nbsp;&nbsp;&nbsp; 3. Restart Process<br><br>';
	$xcommand = sprintf("%s/bin/nagios -v %s/nagios.cfg", $prefix, $etcprefix);
	exec($xcommand, $arlines, $returncode);
	if($returncode > 0 || array_search("Error:", $arlines))
	{
		//		echo '<b>There was an Error verifying the configuration files.</b> <br>Look at the error and make the changes necessary to resolve it.<br>If you can\'t figure it out call Josh 267-2427<br><br>';
		printf('<b>There was an Error Verifying the configuration files.</b> <br>Look at the error and make the changes necessary to resolve it.<br>If you can\'t figure it out call %s at %s<br>or send an e-mail to %s<br><br>', $adminname, $adminphone, $adminemail);
	} else {
		echo '<input type=hidden name=action value="restartprocess">';
		echo '<input type=submit value="Restart the Nagios Process"><br><br>';
	}
	echo '<table width="75%" border="1" align="center">';
	foreach($arlines as $arvalues){
		if (stristr($arvalues, "Warning")){
			printf('<tr><td bgcolor="yellow">%s</td></tr>', $arvalues);
		} elseif (stristr($arvalues, "Error")){
			printf('<tr><td bgcolor="red">%s<br></td></tr>', $arvalues);

			// The line ends with a ) or a . have to check for both cases, this sucks.
			preg_match("/^.*\'(.*)\'.*line(.*)[)]/i", $arvalues, $matches);

			if ($matches[2] < 1)  // If the ) doesn't exist then look for the .
			{
				preg_match("/^.*\'(.*)\'.*line(.*)[\.]/i", $arvalues, $matches);
			}


			if ($matches[2] > 0)
			{
				$ycommand=sprintf('head -n %s %s | tail -n 10', $matches[2] + 10, $matches[1]);
				$line=$matches[2];
				exec($ycommand, $ylines, $returncode);
				echo '<tr><td><b>Below are the 10 lines following the error</b><br>';
				foreach($ylines as $yvalue)
				{
					printf('<b>%s:</b> %s<br>', $line, $yvalue);
					$line++;
				}
				echo '</tr>';
				$matches='';
			}
			//			print_r($yrlines);
		} else {
			printf('<tr><td>%s</td></tr>', $arvalues);
		}
	}
	break;

}

echo '</center></form></body></html>';
?>
