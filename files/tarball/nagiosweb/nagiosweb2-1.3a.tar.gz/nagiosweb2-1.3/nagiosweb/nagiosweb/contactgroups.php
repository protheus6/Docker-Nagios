<?php
include("include.php");
include("dbconfig.php");

switch ($action)
{
	case 'Delete':
	$deletequery=mysql_query("DELETE FROM contactgroups WHERE contactgroup_id='$contactgroup_id'");
	$deletememquery=mysql_query("DELETE FROM contactgroup_members WHERE contactgroup_id='$contactgroup_id'");
	$deleteservicesquery=mysql_query("DELETE FROM service_contactgroups WHERE contactgroup_id='$contactgroup_id'");
	$deletecontactsquery=mysql_query("DELETE FROM hostgroup_contactgroups WHERE contactgroup_id='$contactgroup_id'");
	header("Location:contactgrouplist.php");
	break;
	
	case 'Return to Contact Groups':
	header("Location:contactgrouplist.php");
	break;
}	
if ($ChangeGroup) {
	if (count($member_contact_id_remove)>0) {
		foreach($member_contact_id_remove as $contactinfo) {
			list($contact_id, $alert) = explode('-', $contactinfo);
			$deletequery=mysql_query("DELETE FROM contactgroup_members WHERE contactgroup_id='$contactgroup_id' AND contact_id='$contact_id' AND alert='$alert'");
		}
	}
	if (count($member_contact_id_add)>0) {
		foreach($member_contact_id_add as $contactinfo) {
			list($contact_id, $alert) = explode('-', $contactinfo);
			$insertquery=mysql_query("INSERT INTO contactgroup_members SET contactgroup_id='$contactgroup_id', contact_id='$contact_id', alert='$alert'");
		}
	}
	header("Location:contactgroups.php?contactgroup_id=$contactgroup_id");
}


$contactgroupnamequery=mysql_query("SELECT contactgroup_name FROM contactgroups WHERE contactgroup_id='$contactgroup_id'");
$contactgroup_name=mysql_result($contactgroupnamequery, 0);
?>

<html>
<head>
<title>Contact Group Membership</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<div align="center"><b><font size="5">Contact Group <?php echo $contactgroup_name?></font> <p>
  </b></div>
<form action="contactgroups.php" method="post" name="contactgroupform">
<center>
<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="action" value="Return to Contact Groups">
</center><br>

<input type="hidden" name="contactgroup_id" value="<? echo $contactgroup_id?>">
<input type="hidden" name="contactgroup_name" value="<? echo $contactgroup_name?>">

<div align="center"><b>Contact Group Members</b></div>
  <table align="center" border="1">
    <tr> 
    <tr> 
      
    <td><b>Current Members</b></td>
          <td>&nbsp;&nbsp;</td>
      
    <td><b>Available Members</b></td>
    </tr>
    <?
$groupquery=mysql_query("SELECT * FROM contacts ORDER BY contact_name");
$members = array();
$nonmembers = array();
$alertarray=array('pager', 'email');
while ($mycontact=mysql_fetch_array($groupquery)) {
	$contact_id=$mycontact["contact_id"];
	$contactcheck=mysql_query("SELECT * FROM contactgroup_members WHERE contactgroup_id='$contactgroup_id' AND contact_id='$contact_id'");
	$alertarraycheck=array();
	if (mysql_num_rows($contactcheck) > 0) {
		while ($mycc=mysql_fetch_array($contactcheck)) {
			array_push($members, $mycontact["contact_name"] . "-" . $contact_id . "-" . $mycc["alert"]);
			array_push($alertarraycheck, $mycc["alert"]);
		}
	}
	array_push($alertarraycheck, 'fix');
	$alerts = array_diff($alertarray, $alertarraycheck);
	foreach ($alerts as $alert) {
		array_push($nonmembers, $mycontact["contact_name"] . "-" . $contact_id . "-" . $alert);
	}
}
	echo '<tr align=center><td valign="top"><select name="member_contact_id_remove[]" size="6" multiple>';
foreach($members as $groupnameinfo) {
	list($contactname, $contactid, $alert) = explode('-', $groupnameinfo);
	printf('<option value="%s-%s">%s (%s)<br>', $contactid, $alert, $contactname, $alert);
	echo "\n";
}
	echo '</select></td><td><input type="submit" name="ChangeGroup" value="<-->"></td><td valign="top"><select name="member_contact_id_add[]" size="6" multiple>';

foreach($nonmembers as $groupnameinfo) {
	list($contactname, $contactid, $alert) = explode('-', $groupnameinfo);
	printf('<option value="%s-%s">%s (%s)<br>', $contactid, $alert, $contactname, $alert);
	echo "\n";
}
	echo '</select></td></tr>';
	
?>
  </table>
  <center><br>
<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="action" value="Return to Contact Groups">
</form>
</center>