<?php
include("include.php");
include("dbconfig.php");

$host_notification_options_array=array('Down', 'Up', 'Recovery');
$host_notification_options_default_array=array('Down', 'Recovery');
$service_notification_options_array=array('OK', 'Warn', 'Unkn', 'Crit');
$service_notification_options_default_array=array('OK', 'Warn', 'Unkn', 'Crit');

switch($action) {

	case "Return to Contacts":
	header("Location:contactlist.php");
	break;

	case AddContact:
	$host_notification_options = checkbox_values("host_notification_options", $host_notification_options_array);
	$service_notification_options = checkbox_values("service_notification_options", $service_notification_options_array);
	
	$contactinsertquery = mysql_query("INSERT INTO contacts SET contact_name='$contact_name', alias='$alias', host_notification_options='$host_notification_options', host_notification_period='$host_notification_period', service_notification_options='$service_notification_options', service_notification_period='$service_notification_period', host_notification_command_email='$host_notification_command_email', service_notification_command_email='$service_notification_command_email', host_notification_command_pager='$host_notification_command_pager', service_notification_command_pager='$service_notification_command_pager', email='$email', pager='$pager'");
	$contact_id = mysql_insert_id();
	header("Location:contacts.php?action=contactlookup&contact_id=$contact_id");
	break;

	case contactlookup:
	$fields = mysql_list_fields($nagiosweb, "contacts");
	$columns = mysql_num_fields($fields);
	$mycontactquery = mysql_query("SELECT * FROM contacts WHERE contact_id='$contact_id'");
	$mycontact = mysql_fetch_array($mycontactquery);
	for ($i = 0; $i < $columns; $i++) {
		$tempname = mysql_field_name($fields, $i);
		$$tempname = $mycontact[$tempname];
	}
	break;
	
	case contactsave:
	$host_notification_options = checkbox_values("host_notification_options", $host_notification_options_array);
	$service_notification_options = checkbox_values("service_notification_options", $service_notification_options_array);
	$fields = mysql_list_fields($nagiosweb, "contacts");
	$columns = mysql_num_fields($fields);
	$mycontactquery = mysql_query("SELECT * FROM contacts WHERE contact_id='$contact_id'");
	$mycontact = mysql_fetch_array($mycontactquery);
	for ($i = 0; $i < $columns; $i++) {
		$tempname = mysql_field_name($fields, $i);
		$query = sprintf("%s, %s = '%s'", $query, $tempname, $$tempname);
	}
	
	if (stristr(substr($query, 0, 2),",")) {
		$query=substr($query, 2);
	}

	$query = sprintf("UPDATE contacts SET %s where contact_id='$contact_id'", $query);
	$queryresult = mysql_query($query);
	header("Location:contacts.php?action=contactlookup&contact_id=$contact_id");
	break;
	
	case Delete:
	$delquery = mysql_query("DELETE FROM contacts WHERE contact_id='$contact_id'");
	$delgrpquery = mysql_query("DELETE FROM contact_group_members WHERE contact_id='$contact_id'");
	header("Location:contactlist.php");
	break;
	
	default:
	$host_notification_period='1'; // 24x7
	$service_notification_period='1'; //24x7
	break;
	
}	

?>

<form action="contacts.php" method="post">
<input type="hidden" name="contact_id" value="<? echo $contact_id ?>">
<input type="hidden" name="contactgroup_id" value="<? echo $hostgroup_id ?>">
<input type="hidden" name="action" value="contactsave">

<center>
<?
if ($action == 'contactlookup') {
	echo '<input type="submit" name="submit" value="Submit Info">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Return to Contacts">';
} else {
	echo '<input type="hidden" name="action" value="AddContact">';
	echo '<input type="submit" name="submit" value="Add Contact">&nbsp;&nbsp;&nbsp;&nbsp;';
}	
?>
</center><br>
<table align="center" border="1" cellspacing="2" cellpadding="0" width="800">
<tr><td colspan="4" align="center"><b>Contact Details</b></td></tr>
<tr>
      <td width="200"><strong>Contact Name:</strong></td>
      <td width="200"><input type="text" name="contact_name" value="<? echo $contact_name ?>"></td>
      <td width="200"><strong>Alias:</strong></td>
      <td width="200"><input type="text" name="alias" value="<? echo $alias ?>"></td></tr>
<tr>
      <td><strong>E-Mail Address:</strong></td>
<td><input type="text" name="email" value="<? echo $email ?>"></td>
      <td><strong>Pager:</strong></td>
<td><input type="text" name="pager" value="<? echo $pager ?>"></td>
</tr>
<tr>
      <td><strong>Host Notification Period:</strong></td>
<td>
<?
dropdown_resolver("host_notification_period", "timeperiod_id", "alias", $host_notification_period, "timeperiods");
?>
</td>
      <td><strong>Service Notification Period:</strong></td>
<td>
<?
dropdown_resolver("service_notification_period", "timeperiod_id", "alias", $service_notification_period, "timeperiods");
?>
</td></tr><tr>
      <td><strong>Host Notify On:</strong></td>
<td>
<?
$host_notification_options = checkbox_resolver('host_notification_options', $host_notification_options_array, $host_notification_options, $host_notification_options_default_array);
?>
</td>
      <td><strong>Service Notify On:</strong></td>
<td>
<?
$service_notification_options = checkbox_resolver('service_notification_options', $service_notification_options_array, $service_notification_options, $service_notification_options_default_array);
?>
</td>
</td></tr>
<tr>
      <td><strong>Host E-Mail Notification:</strong></td>
<td>
<?
dropdown_resolver("host_notification_command_email", "command_id", "command_name", $host_notification_command_email, "notify");
?>
</td>
      <td><strong>Service E-Mail Notification:</strong></td>
<td>
<?
dropdown_resolver("service_notification_command_email", "command_id", "command_name", $service_notification_command_email, "notify");
?>
</td></tr>
<tr>
      <td><strong>Host Pager Notification:</strong></td>
<td>
<?
dropdown_resolver("host_notification_command_pager", "command_id", "command_name", $host_notification_command_pager, "notify");
?>
</td>
      <td><strong>Service Pager Notification:</strong></td>
<td>
<?
dropdown_resolver("service_notification_command_pager", "command_id", "command_name", $service_notification_command_pager, "notify");
?>
</td></tr>
</table><br><center>
<?
if ($action == 'contactlookup') {
	echo '<input type="submit" name="submit" value="Submit Info">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Return to Contacts">';
} else {
	echo '<input type="hidden" name="action" value="AddContact">';
	echo '<input type="submit" name="submit" value="Add Contact">&nbsp;&nbsp;&nbsp;&nbsp;';

}	
?>
</center>
</form>