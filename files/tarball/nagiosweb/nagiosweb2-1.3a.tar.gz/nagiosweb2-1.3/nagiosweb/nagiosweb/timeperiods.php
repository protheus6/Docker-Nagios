<?php

include("include.php");
include("dbconfig.php");
$daysofweek=array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');

switch($action) {
	
	case "Return to Time Periods":
	header("Location:timeperiodlist.php");
	break;	
	
	case timeperiodsave:
	$query ='';
	foreach ($daysofweek as $day) {
		$query = sprintf("%s, %s = '%s'", $query, $day, $$day);
	}
	
	if (stristr(substr($query, 0, 2),",")) {
		$query=substr($query, 2);
	}
	$updatequery=mysql_query("UPDATE timeperiods SET timeperiod_name='$timeperiod_name', alias='$alias', $query WHERE timeperiod_id='$timeperiod_id'");
	header("Location:timeperiods.php?action=tplookup&timeperiod_id=$timeperiod_id");	
	break;

	case Delete:
	$usecount=0;
	$hostquery=mysql_query("SELECT host_name FROM hosts WHERE notification_period='$timeperiod_id'");
	$usecount=$usecount + mysql_num_rows($hostquery);
	while ($myhost=mysql_fetch_array($hostquery)) {
		printf('<center>Host <font color=red>%s</font><br>', $myhost["host_name"]);
	}
	$servicequery=mysql_query("SELECT service_description FROM services WHERE notification_period='$timeperiod_id' OR check_period='$timeperiod_id'");
	$usecount=$usecount + mysql_num_rows($servicequery);
	while ($myserv=mysql_fetch_array($servicequery)) {
		printf('Service <font color=red>%s</font><br>', $myserv["service_description"]);
	}
	$contactquery=mysql_query("SELECT contact_name FROM contacts WHERE host_notification_period='$timeperiod_id' OR service_notification_period='$timeperiod_id'");
	$usecount=$usecount + mysql_num_rows($contactquery);
	while ($mycont=mysql_fetch_array($contactquery)) {
		printf('Contact <font color=red>%s</font><br>', $mycont["contact_name"]);
	}
	if ($usecount > 0) {
		printf('<center>These objects use the %s time period, you will need to change them before you can delete this time period.<br>', $timeperiod_name);
	} else {
		$delquery =mysql_query("DELETE FROM timeperiods WHERE timeperiod_id='$timeperiod_id'");
		header("Location:timeperiodlist.php");	
	}
	$action='tplookup';
	break;
	
	case AddTimePeriod:
	$query ='';
	foreach ($daysofweek as $day) {
		$query = sprintf("%s, %s = '%s'", $query, $day, $$day);
	}
	
	if (stristr(substr($query, 0, 2),",")) {
		$query=substr($query, 2);
	}

	$insertquery=sprintf("INSERT INTO timeperiods SET %s, timeperiod_name='$timeperiod_name', alias='$alias'", $query);
	$insertquery=mysql_query($insertquery);
	header("Location:timeperiodlist.php");	
	break;
	
	case tplookup:
	$query=mysql_query("SELECT * FROM timeperiods WHERE timeperiod_id='$timeperiod_id'");
	$mytp=mysql_fetch_array($query);
	$timeperiod_name=$mytp["timeperiod_name"];
	$alias=$mytp["alias"];
	foreach ($daysofweek as $day) {
		$$day = $mytp[(strtolower($day))];
	}
	

}
	
?>

<form action="timeperiods.php" method="post">
<input type="hidden" name="timeperiod_id" value="<? echo $timeperiod_id ?>">
<input type="hidden" name="action" value="timeperiodsave">

<center>
<?
if ($action == 'tplookup') {
	echo '<input type="submit" name="submit" value="Submit Info">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Return to Time Periods">';
} else {
	echo '<input type="hidden" name="action" value="AddTimePeriod">';
	echo '<input type="submit" name="submit" value="Add Time Period">&nbsp;&nbsp;&nbsp;&nbsp;';
}	
?>
</center><br>
<table align="center" border="1" cellspacing="2" cellpadding="0" width="600">
<tr><td colspan="2" align="center"><b>Time Period Details</b></td></tr>
<tr>
    <td><strong>Time Period Name:</strong></td>
    <td><input type=text name="timeperiod_name" value="<? echo $timeperiod_name ?>"></td></tr>
<tr>
    <td><strong>Time Period Alias:</strong></td>
    <td><input type=text name="alias" value="<? echo $alias ?>"></td></tr>
<?
foreach($daysofweek as $day) {
	printf('<tr><td><b>%s:</b></td><td><input type=text name="%s" value="%s"></td></tr>', $day, $day, $$day);
}
?>
</table>
<center><br>
<?
if ($action == 'tplookup') {
	echo '<input type="submit" name="submit" value="Submit Info">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Return to Time Periods">';
} else {
	echo '<input type="hidden" name="action" value="AddTimePeriod">';
	echo '<input type="submit" name="submit" value="Add Time Period">&nbsp;&nbsp;&nbsp;&nbsp;';
}	
?>
</center><br>

	