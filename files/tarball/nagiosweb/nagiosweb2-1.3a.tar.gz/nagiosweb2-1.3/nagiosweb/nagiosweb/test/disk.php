<?php
//include("include.php");
include("../dbconfig.php");

$host_name=$_POST["host_name"];
$host_id=$_POST["host_id"];
$username='root';
$pw='guide1';
$dirserver='nagios';
$dircmd =sprintf('/opt/IBM/director/bin/dircmd -s %s -u %s -p %s', $dirserver, $username, $pw);


// Function to get groups from Director to director_groups array
function get_director_groups() {
	global $dircmd;
	exec($dircmd.' server listgroups', $arlines, $returncode);
	return $arlines;
}  // End Function

// Function to get servers from Director to director_server array
function get_director_servers() {
	global $dircmd;
	exec($dircmd.' server listobjects', $arlines, $returncode);
	return $arlines;
}  // End Function


switch ($op) {
	
	case addgroup:
	exec($dircmd.' server createstaticgroup '.$_POST["newgroup"], $arlines, $returncode);
	break;

}



foreach(get_director_groups() as $arvalues){
	list($group_oid, $group_name) = explode('  ', $arvalues);
	printf('%s - %s<br>', $group_oid, $group_name);
}

//foreach(get_director_servers() as $arvalues){
//	list($server_oid, $server_name) = explode('  ', $arvalues);
//	printf('%s - %s<br>', $server_oid, $server_name);
//}

?>
<b>Add New Group</b><br>
<form action="<? echo $PHP_SELF?>" method="post">
<input type="hidden" name="op" value="addgroup">
<input type="text" name="newgroup"><br>
<input type="submit">
</form>
