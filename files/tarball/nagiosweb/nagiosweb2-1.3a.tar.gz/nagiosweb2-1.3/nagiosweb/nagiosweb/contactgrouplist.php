<?php
//include("include.php");
include("dbconfig.php");

if ($contactgroup_name) {
	$insertquery=mysql_query("INSERT INTO contactgroups SET contactgroup_name='$contactgroup_name'");
	$contactgroup_id=mysql_insert_id();
	header("Location:contactgroups.php?contactgroup_id=$contactgroup_id&contactgroup_name=$contactgroup_name");
}

//include("top.php");


?>
<center><form action="contactgrouplist.php" method="post">
<input type="text" name="contactgroup_name">&nbsp;&nbsp;<input type="submit" name="AddContactGroup" value="Add Contact Group">
</form></center>
<table align="center" border="1" cellpadding="2" cellspacing="0" width="600">
  <tr align="center"> 
    <td width="200"><strong>Contact Group Name</strong></td>
    <td width="400"><strong>Members</strong></td>
  </tr>
<?
$query = mysql_query("SELECT * FROM contactgroups WHERE alias='' ORDER BY contactgroup_name");
while ($mycg=mysql_fetch_array($query)) {
	printf('<tr STYLE="cursor: hand" valign=top><td><a href="contactgroups.php?contactgroup_id=%s">%s</a></td><td><table border=1 width=100%%><tr>', $mycg["contactgroup_id"], $mycg["contactgroup_name"]);
	$contactgroup_id = $mycg["contactgroup_id"];
	$i=0;
	$memberquery = mysql_query("SELECT contacts.contact_id, contacts.contact_name, contactgroup_members.alert FROM contacts, contactgroup_members WHERE contactgroup_members.contactgroup_id='$contactgroup_id' and contacts.contact_id = contactgroup_members.contact_id");
	while ($mymember=mysql_fetch_array($memberquery)) {
		if ($i>2) {
			echo '</tr><tr>';
			$i=0;
			}
		$i++;
		printf("<td align=center width=33%%><a href='contacts.php?action=contactlookup&contact_id=%s'>%s (%s)</a></td>\n", $mymember["contact_id"], $mymember["contact_name"], $mymember["alert"]);
	}
	echo "</table></td>";
}

?>