<?php
include("include.php");
include("dbconfig.php");

$notification_options_array=array('Down', 'Up', 'Recovery');
$notification_options_default_array=array('Down', 'Recovery');
$stalking_options_array=array('Down', 'Up', 'Unreachable');
$stalking_options_default_array=array();
$execution_failure_criteria_array=array('OK', 'Warn', 'Unkn', 'Crit');
$execution_failure_criteria_default_array=array();
$notification_failure_criteria_array=array('OK', 'Warn', 'Unkn', 'Crit');
$notification_failure_criteria_default_array=array();

$execution_failure_criteria = checkbox_values('execution_failure_criteria', $execution_failure_criteria_array);
$notification_failure_criteria = checkbox_values('notification_failure_criteria', $notification_failure_criteria_array);

if ($ChangeGroup) {
	if (count($member_contact_id_remove)>0) {
		foreach($member_contact_id_remove as $contactgroup_id) {
			$deletequery=mysql_query("DELETE FROM host_contactgroups WHERE contactgroup_id='$contactgroup_id' AND host_id='$host_id'");
		}
	}
	if (count($member_contact_id_add)>0) {
		foreach($member_contact_id_add as $contactgroup_id) {
			$deletequery=mysql_query("INSERT INTO host_contactgroups SET contactgroup_id='$contactgroup_id', host_id='$host_id'");
		}
	}
	header("Location:hosts.php?host_id=$host_id");
}

if ($ChangeHostDep) {
	if (count($dependent_host_id_remove)>0) {
		foreach($dependent_host_id_remove as $depvalue) {
			$remquery = mysql_query("DELETE FROM hostdependency WHERE dependent_host_id='$host_id' and host_id='$depvalue'");
		}
	}
	if (count($dependent_host_id_add)>0) {
		foreach($dependent_host_id_add as $depvalue) {
			$addquery = mysql_query("INSERT INTO hostdependency SET dependent_host_id='$host_id', host_id='$depvalue', dependent_host_name='$dependent_host_name', host_name='$host_name'");
		}
	}
}


if ($ChangeParent) {
	if (count($parent_remove)>0) {
		foreach($parent_remove as $parent_host_id) {
			$remquery = mysql_query("DELETE FROM host_parents WHERE parent_host_id='$parent_host_id' and host_id='$host_id'");
		}
	}
	if (count($parent_add)>0) {
		foreach($parent_add as $parent_host_id) {
			$addquery = mysql_query("INSERT INTO host_parents SET parent_host_id='$parent_host_id', host_id='$host_id'");
		}
	}
}



if ($service_id) {
	$deletequery=mysql_query("DELETE FROM hostgroup_services WHERE service_id='$service_id' AND hostgroup_id='$hostgroup_id'");
	$deletedepquery=mysql_query("DELETE FROM servicedependency WHERE services.service_id='$service_id' AND servicedependency.service_description=services.service_description AND servicedependency.host_id='$host_id'");
	header("Location:hosts.php?action=hostlookup&host_id=$host_id");
}

if ($AddService  && (count($contactgroup_id)>0)) {
	foreach($contactgroup_id as $cg_id) {
		$deletequery=mysql_query("INSERT INTO hostgroup_services SET service_id='$service_id_add', hostgroup_id='$hostgroup_id', contactgroup_id='$cg_id'");
	}
	header("Location:hosts.php?action=hostlookup&host_id=$host_id");
}


switch($action) {

	case 'Return to Hosts':
	header("Location:hostlist.php");
	break;

	case AddHost:
	$notification_options = checkbox_values("notification_options", $notification_options_array);
	$stalking_options = checkbox_values("stalking_options", $stalking_options_array);

	$hostgroupinsertquery = "INSERT INTO hostgroups SET hostgroup_name='$host_name', alias='$alias'";
	$hostgroupinsertqueryresult = mysql_query($hostgroupinsertquery);
	$hostgroup_id=mysql_insert_id();

	$fields = mysql_list_fields($nagiosweb, "hosts");
	$columns = mysql_num_fields($fields);
	for ($i = 1; $i < $columns; $i++) {
		$tempname = mysql_field_name($fields, $i);
		$query = sprintf("%s, %s = '%s'", $query, $tempname, $$tempname);
	}


	if (stristr(substr($query, 0, 2),",")) {
		$query=substr($query, 2);
	}

	$hostinsertquery = sprintf("INSERT INTO hosts SET %s", $query);
	$hostinsertqueryresult = mysql_query($hostinsertquery);
	$host_id=mysql_insert_id();
	$hostgroupmemberquery = "INSERT INTO hostgroup_members SET hostgroup_id='$hostgroup_id', host_id='$host_id'";
	$hostgroupmemberqueryresult = mysql_query($hostgroupmemberquery);
	header("Location:hosts.php?action=hostlookup&host_id=$host_id");
	break;

	case hostlookup:
	$fields = mysql_list_fields($nagiosweb, "hosts");
	$columns = mysql_num_fields($fields);
	$myhostquery = mysql_query("SELECT * FROM hosts WHERE host_id='$host_id'");
	$myhost = mysql_fetch_array($myhostquery);
	for ($i = 0; $i < $columns; $i++) {
		$tempname = mysql_field_name($fields, $i);
		$$tempname = $myhost[$tempname];
	}
	break;

	case Delete:
	echo "<center><b><font color=red>Are you sure you want to delete this host ?</font></b></center>";
	break;

	case confirmed:
	$hostdeletequery = mysql_query("DELETE FROM hosts WHERE host_id='$host_id'");
	$hostservdeletequery = mysql_query("DELETE FROM services WHERE host_id='$host_id'");
	$hostservhgdeletequery = mysql_query("DELETE FROM services WHERE hostgroup_id='$hostgroup_id'");
	$hostparentdeletequery = mysql_query("DELETE FROM host_parents WHERE host_id='$host_id'");
	$hostdepdeletequery = mysql_query("DELETE FROM hostdependency WHERE dependent_host_id='$host_id' or host_id='$host_id'");
	$hostservdepquery = mysql_query("DELETE FROM servicedependency WHERE host_id='$host_id'");
	$hostgroupdeletequery = mysql_query("DELETE FROM hostgroups WHERE hostgroup_id='$hostgroup_id'");
	$hostgroupservicesdeletequery = mysql_query("DELETE FROM hostgroup_services WHERE hostgroup_id='$hostgroup_id'");
	$hostgroupmembersdeletequery = mysql_query("DELETE FROM hostgroup_members WHERE hostgroup_id='$hostgroup_id'");
	$hostgroupcontactsdeletequery = mysql_query("DELETE FROM hostgroup_contactgroups WHERE hostgroup_id='$hostgroup_id'");
	$servdepquery = mysql_query("DELETE FROM servicedependency WHERE dependent_host_id='$host_id'");
	header("Location:hostlist.php");
	break;

	case hostsave:
	$notification_options = checkbox_values("notification_options", $notification_options_array);
	$stalking_options = checkbox_values("stalking_options", $stalking_options_array);
	$fields = mysql_list_fields($nagiosweb, "hosts");
	$columns = mysql_num_fields($fields);
	for ($i = 0; $i < $columns; $i++) {
		$tempname = mysql_field_name($fields, $i);
		$query = sprintf("%s, %s = '%s'", $query, $tempname, $$tempname);
	}

	if (stristr(substr($query, 0, 2),",")) {
		$query=substr($query, 2);
	}

	$query = sprintf("UPDATE hosts SET %s WHERE host_id = '$host_id'", $query);
	$queryresult = mysql_query($query);
	$servicedependencyupdate = mysql_query("UPDATE servicedependency SET host_name='$host_name' WHERE host_id='$host_id'");
	$servicedependencyupdate2 = mysql_query("UPDATE servicedependency SET dependent_host_name='$host_name' WHERE dependent_host_id='$host_id'");
	$hgquery = "UPDATE hostgroups SET hostgroup_name='$host_name', alias='$alias' WHERE hostgroup_id='$hostgroup_id'";
	$hgqueryresult = mysql_query($hgquery);
	header("Location:hosts.php?action=hostlookup&host_id=$host_id");
	break;


	case Duplicate:
	$fields = mysql_list_fields($nagiosweb, "hosts");
	$columns = mysql_num_fields($fields);
	$myhostquery = mysql_query("SELECT * FROM hosts WHERE host_id='$host_id'");
	$myhost = mysql_fetch_array($myhostquery);
	for ($i = 0; $i < $columns; $i++) {
		$tempname = mysql_field_name($fields, $i);
		$$tempname = $myhost[$tempname];
	}
	$host_id='';
	$hostgroup_id='';
	$host_name='';
	$alias='';
	$address='';
	$action=NULL;
	break;

	case removeservice:
	$deletequery=mysql_query("DELETE FROM hostgroup_services WHERE service_id='$service_id' AND hostgroup_id='$hostgroup_id'");
	$deletedepquery=("DELETE FROM servicedependency WHERE services.service_id='$service_id' AND servicedependency.service_description=services.service_description AND servicedependency.host_id='$host_id'");
	header("Location:hosts.php?action=hostlookup&host_id=$host_id");
	break;

	case RemoveServiceDep:
	$delquery = mysql_query("DELETE FROM servicedependency WHERE servicedependency_id='$servicedependency_id'");
	header("Location:hosts.php?action=hostlookup&host_id=$host_id");
	break;

	case removedowntime:
	$delquery = mysql_query("DELETE FROM downtime WHERE downtime_id='$downtime_id'");
	header("Location:hosts.php?action=hostlookup&host_id=$host_id");
	break;

	default:
	// Set Default values because we're adding a new host from scratch
	$check_command='3';  // This is the id of check_host_alive
	$max_check_attempts='3';
	$notification_interval='30';
	$notification_period='1';  // This is the id of the 24x7 timeperiod
	break;
}

?>

<form action="hosts.php" method="post">
<input type="hidden" name="host_id" value="<? echo $host_id ?>">
<input type="hidden" name="hostgroup_id" value="<? echo $hostgroup_id ?>">
<input type="hidden" name="action" value="hostsave">
<center>
<?
if ($action == 'hostlookup') {
	echo '<input type="submit" name="submit" value="Submit Info">&nbsp;&nbsp;&nbsp;&nbsp;';
	printf('<input type=hidden name="host_id" value="%s">', $host_id);
	echo '<input type="submit" name="action" value="Duplicate">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;';
} elseif ($action == 'Delete') {
	printf('<a href="hosts.php?action=confirmed&host_id=%s&hostgroup_id=%s">Yes Delete It !"</a>&nbsp;&nbsp;&nbsp;&nbsp;', $host_id, $hostgroup_id);
} else {
	echo '<input type="hidden" name="action" value="AddHost">';
	echo '<input type="submit" name="submit" value="Add Host">&nbsp;&nbsp;&nbsp;&nbsp;';
}
?>
<input type="submit" name="action" value="Return to Hosts">
</center><br>
<table align="center" border="1" cellspacing="2" cellpadding="0" width="800">
<tr><td colspan="4" align="center"><b>Host Details</b></td></tr>
<tr>
      <td width="200"><strong>Host Name:</strong></td>
      <td width="200"><input type="text" name="host_name" value="<? echo $host_name ?>"></td>
      <td width="200"><strong>Alias:</strong></td>
      <td width="200"><input type="text" name="alias" value="<? echo $alias ?>"></td></tr>
<tr>
      <td><strong>Address:</strong></td>
      <td><input type="text" name="address" value="<? echo $address ?>"></td>
</td></tr>

</table><br>
<table align="center" border="1" cellspacing="2" cellpadding="0" width="800">
<tr><td colspan="4" align="center"><b>Check Details</b></td></tr>
<tr>
      <td width="200"><strong>Checks Enabled:</strong></td>
      <td width="200">
<?
$checks_enabled_array=array('Yes', 'No');
radio_button_resolver('checks_enabled', $checks_enabled_array, $checks_enabled, 'Yes');
?>
</td>
	  <td width="200"><strong>Check Command:</strong></td>
      <td width="200">
<?
dropdown_resolver("check_command", "command_id", "command_name", $check_command, "command");
?>
</td>
</tr>
<tr>
<td><strong>Notifications Enabled:</strong></td>
      <td>
<?
$notifications_enabled_array=array('Yes', 'No');
radio_button_resolver('notifications_enabled', $notifications_enabled_array, $notifications_enabled, 'Yes');
?>
</td>
<td><strong>Notify On:</strong></td>
      <td>
<?
$notification_options = checkbox_resolver('notification_options', $notification_options_array, $notification_options, $notification_options_default_array);
?>
</td></tr>
<tr>
      <td><strong>Max Check Attempts:</strong></td>
      <td><input type="text" name="max_check_attempts" size="4" value="<? echo $max_check_attempts ?>"></td>
	        <td><strong>Notification Period:</strong></td>
      <td>
<?
dropdown_resolver("notification_period", "timeperiod_id", "alias", $notification_period, "timeperiods");
?>
</td></tr>
<tr>
      <td colspan="2">&nbsp;</td>
      <td><strong>Notification Interval:</strong></td>
      <td><input type="text" name="notification_interval" size="4" value="<? echo $notification_interval ?>"> minutes</td></tr>
<tr>
	  <td><strong>Event Handler Enabled:</strong></td>
      <td>
<?
$event_handler_enabled_array=array('Yes', 'No');
radio_button_resolver('event_handler_enabled', $event_handler_enabled_array, $event_handler_enabled, 'No');
?>
</td>
      <td><strong>Event Handler:</strong></td>
      <td>
<?
dropdown_resolver("event_handler", "command_id", "command_name", $event_handler, "command");
?>
</td></tr>
<tr>
      <td><strong>Flap Detection Enabled:</strong></td>
      <td>
<?
$flap_detection_enabled_array=array('Yes', 'No');
radio_button_resolver('flap_detection_enabled', $flap_detection_enabled_array, $flap_detection_enabled, 'No');
?>
</td>
      <td><strong>Low Flap Threshold:</strong></td>
      <td><input type="text" name="low_flap_threshold" size="4" value="<? echo $low_flap_threshold ?>"></td></tr>
<tr>
      <td colspan="2">&nbsp;</td>
	  <td><strong>High Flap Threshold:</strong></td>
      <td><input type="text" name="high_flap_threshold" size="4" value="<? echo $high_flap_threshold ?>"></td></tr>
<tr>
      <td><strong>Process Performance Data:</strong></td>
      <td>
<?
$process_perf_data_array=array('Yes', 'No');
radio_button_resolver('process_perf_data', $process_perf_data_array, $process_perf_data, 'No');
?>
</td>
	  <td><strong>Stalking Options:</strong></td>
      <td>
<?
$stalking_options = checkbox_resolver('stalking_options', $stalking_options_array, $stalking_options, $stalking_options_default_array);
?>
</td>
</tr>
<tr>
      <td><strong>Retain Status Info:</strong></td>
      <td>
<?
$retain_status_information_array=array('Yes', 'No');
radio_button_resolver('retain_status_information', $retain_status_information_array, $retain_status_information, 'Yes');
?>
</td>
	  <td><strong>Retain Non-Status Info:</strong></td>
      <td>
<?
$retain_nonstatus_information_array=array('Yes', 'No');
radio_button_resolver('retain_nonstatus_information', $retain_nonstatus_information_array, $retain_nonstatus_information, 'Yes');
?>
</td></tr>
</table><br>
<?
if (isset($action))
{
?>
	
<div align="center"><b>Host Contact Groups</b></div>
  <table align="center" border="1">
    <tr> 
    <tr> 
      
    <td><b>Current Groups</b></td>
          <td>&nbsp;&nbsp;</td>
      
    <td><b>Available Groups</b></td>
    </tr>
    <?
    $groupquery=mysql_query("SELECT * FROM contactgroups ORDER BY contactgroup_name");
    $members = array();
    $nonmembers = array();
    while ($mygroup=mysql_fetch_array($groupquery)) {
    	$contactgroup_id=$mygroup["contactgroup_id"];
    	$hostcheck=mysql_query("SELECT * FROM host_contactgroups WHERE host_id='$host_id' AND contactgroup_id='$contactgroup_id'");
    	if (mysql_num_rows($hostcheck) > 0) {
    		$members[$contactgroup_id] = $mygroup["contactgroup_name"];
    	} else {
    		$nonmembers[$contactgroup_id] = $mygroup["contactgroup_name"];
    	}
    }
    echo '<tr align=center><td valign="top"><select name="member_contact_id_remove[]" size="6" multiple>';
    foreach($members as $groupid => $groupname) {
    	printf('<option value="%s">%s<br>', $groupid, $groupname);
    	echo "\n";
    }
    echo '</select></td><td><input type="submit" name="ChangeGroup" value="<-->"></td><td valign="top"><select name="member_contact_id_add[]" size="6" multiple>';

    foreach($nonmembers as $groupid => $groupname) {
    	printf('<option value="%s">%s<br>', $groupid, $groupname);
    	echo "\n";
    }
    echo '</select></td></tr>';

?>
</table><br>
<table align="center"><tr><td>
<?
// Moved to 337
//if (isset($action)) {
?>
	<center>

    <b>Host Dependancies</b> 
	<table align="center" border="1">
	<tr align="center">
		  <td><strong>Dependant</strong></td><td>&nbsp;</td>
		  <td><strong>NOT Dependant</strong></td> 
	</tr>
	<tr align="center"><td>
			
<?

$hostquery=mysql_query("SELECT host_id, host_name FROM hosts WHERE host_id<>'$host_id' ORDER BY host_name");
$members = array();
$nonmembers = array();
while ($myhost=mysql_fetch_array($hostquery)) {
	$hostcheck_id = $myhost["host_id"];
	$hostcheck_name = $myhost["host_name"];
	$hostcheck=mysql_query("SELECT host_id FROM hostdependency WHERE host_id='$hostcheck_id' and dependent_host_id='$host_id'");
	if (mysql_num_rows($hostcheck) > 0) {
		$members[$hostcheck_id] = $hostcheck_name;
	} else {
		$nonmembers[$hostcheck_id] = $hostcheck_name;
	}
}
echo '<select name="dependent_host_id_remove[]" size="6" multiple>';

foreach($members as $hostcheckid => $hostcheckname) {
	printf('<option value="%s">%s</option><br>', $hostcheckid, $hostcheckname);
	echo "\n";
}
?>
	</select></td>
	<td>
	<input type="submit" name="ChangeHostDep" value="<-->">
	</td>
	<td>
			<select name="dependent_host_id_add[]" size="6" multiple>
	<?
	foreach($nonmembers as $hostcheckid => $hostcheckname) {
		printf('<option value="%s">%s</option><br>', $hostcheckid, $hostcheckname);
		echo "\n";
	}
	?>
			</select></td>		
		</tr>
	</table></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td>
	
	
	<center>
          <b>Host Parents</b> 
        </center>
	<table align="center" border="1">
	<tr align="center">
		  <td><strong>Dependant</strong></td><td>&nbsp;</td>
		  <td><strong>NOT Dependant</strong></td> 
	</tr>
	<tr align="center"><td>
			
<?

$parentquery=mysql_query("SELECT host_id, host_name FROM hosts WHERE host_id<>'$host_id' ORDER BY host_name");
$members = array();
$nonmembers = array();
while ($myhost=mysql_fetch_array($parentquery)) {
	$hostcheck_id = $myhost["host_id"];
	$hostcheck_name = $myhost["host_name"];
	$hostcheck=mysql_query("SELECT parent_host_id FROM host_parents WHERE parent_host_id='$hostcheck_id' and host_id='$host_id'");
	if (mysql_num_rows($hostcheck) > 0) {
		$members[$hostcheck_id] = $hostcheck_name;
	} else {
		$nonmembers[$hostcheck_id] = $hostcheck_name;
	}
}
echo '<select name="parent_remove[]" size="6" multiple>';

foreach($members as $hostcheckid => $hostcheckname) {
	printf('<option value="%s">%s</option><br>', $hostcheckid, $hostcheckname);
	echo "\n";
}
?>
	</select></td>
	<td>
	<input type="submit" name="ChangeParent" value="<-->">
	</td>
	<td>
			<select name="parent_add[]" size="6" multiple>
	<?
	foreach($nonmembers as $hostcheckid => $hostcheckname) {
		printf('<option value="%s">%s</option><br>', $hostcheckid, $hostcheckname);
		echo "\n";
	}
	?>
			</select></td>		
		</tr>
</table></td></tr></table><br><center><b>Scheduled Downtime</b>
	
<?
echo '<table align="center" border="1">';
$downtimequery=mysql_query("SELECT * FROM downtime WHERE host_id='$host_id'");
if (mysql_num_rows($downtimequery)>0) {
	while ($downtime=mysql_fetch_array($downtimequery)) {
		printf('<tr><td>Scheduled down at <b>%s</b> on every <b>%s</b> for <b>%s</b> minutes (%s)</td><td><a href="downtimehost.php?downtime_id=%s">Edit</a></td><td><a href="hosts.php?host_id=%s&action=removedowntime&downtime_id=%s">Delete</a></td></tr>', $downtime["starttime"], $downtime["days"], $downtime["duration"]/60, $downtime["comments"], $downtime["downtime_id"], $host_id, $downtime["downtime_id"]);
	}
} else {
	echo "<tr><td>No Downtime Scheduled</td></tr>";
}
echo "</table>";
printf('<br><a href="downtimehost.php?host_id=%s&host_name=%s">Schedule Downtime</a></center>', $host_id, $host_name);
?>	
	
<br><div align="center"><b>Host Services</b></div>
	  <table align="center" border="1" width="600">
		<tr> 
		<tr> 
		  
		<td width="100"><b>Service</b></td>
		<td width="100"><b>Check Time</b></td>
		<td width="100"><b>Notify Time</b></td>
		  
		<td width="125"><b>Contact Group(s)</b></td>
			  <td>&nbsp;&nbsp;</td>
		</tr>
	<?
	$servicequery=mysql_query("SELECT service_id, service_description, check_period, notification_period FROM services WHERE host_id='$host_id' ORDER BY service_description");
	while ($service=mysql_fetch_array($servicequery)) {
		$notq=sprintf("SELECT timeperiod_name FROM timeperiods WHERE timeperiod_id='%s'", $service["notification_period"]);
		$notq=mysql_query($notq);
		if (mysql_num_rows($notq)>0)
		{
			$notification_period=mysql_result($notq, 0);
		} else {
			$notification_period='<b><font color=red>Not Set</font></b>';
		}
		$checkq=sprintf("SELECT timeperiod_name FROM timeperiods WHERE timeperiod_id='%s'", $service["check_period"]);
		$checkq=mysql_query($checkq);
		if (mysql_num_rows($checkq)>0)
		{
			$check_period=mysql_result($checkq, 0);
		} else {
			$check_period='<b><font color=red>Not Set</font></b>';
		}
		printf('<tr><td>%s</td><td>%s</td><td>%s</td><td>', $service["service_description"], $check_period, $notification_period);
		$service_id=$service["service_id"];
		$cgquery=mysql_query("SELECT contactgroups.contactgroup_name FROM contactgroups, service_contactgroups WHERE service_contactgroups.service_id='$service_id' AND contactgroups.contactgroup_id=service_contactgroups.contactgroup_id ORDER BY contactgroups.contactgroup_name");
		if (mysql_num_rows($cgquery)>0)
		{
			while ($mycg=mysql_fetch_array($cgquery)) {
				printf('%s<br>', $mycg["contactgroup_name"]);
			}
		} else {
			echo '<b><font color=red>None Set</font></b>';
		}

		printf('</td><td><a href="services.php?host_id=%s&service_id=%s&action=servicelookup">Edit</a>&nbsp;<a href="services.php?host_id=%s&service_id=%s&action=Delete">Delete</a>&nbsp;<a href="services.php?host_id=%s&service_id=%s&action=Duplicate">Copy It</a></tr>', $host_id, $service["service_id"], $host_id, $service["service_id"], $host_id, $service["service_id"]);
	}
	?>
	</table>
	<?
	printf('<br><center><a href="services.php?&host_id=%s">Add Service to Host</center></a>', $host_id);
	?>
	</td></tr></table>
	

	<?
	$hostgroupquery=mysql_query("SELECT hostgroups.hostgroup_name, hostgroups.hostgroup_id FROM hostgroups, hostgroup_members WHERE hostgroup_members.host_id='$host_id' AND hostgroups.hostgroup_id=hostgroup_members.hostgroup_id AND alias='' ORDER BY hostgroup_name");
	while ($myhg=mysql_fetch_array($hostgroupquery)) {
		$hostgroup_id=$myhg["hostgroup_id"];
		$hostgroup_name=$myhg["hostgroup_name"];
		printf("<br>\n<center><b>Inherited from %s Host Group</b></center>", $hostgroup_name);
		echo '<table align="center" border="1" width=600><tr> <td width="100"><b>Service</b></td><td width="100"><b>Check Time</b></td><td width="100"><b>Notify Time</b></td><td width="125"><b>Contact Group(s)</b></td></tr>';
		$servicequery=mysql_query("SELECT service_id, service_description, check_period, notification_period FROM services WHERE hostgroup_id='$hostgroup_id' ORDER BY service_description");
		while ($service=mysql_fetch_array($servicequery)) {
			$notq=sprintf("SELECT timeperiod_name FROM timeperiods WHERE timeperiod_id='%s'", $service["notification_period"]);
			$notq=mysql_query($notq);
			$notification_period=mysql_result($notq, 0);
			$checkq=sprintf("SELECT timeperiod_name FROM timeperiods WHERE timeperiod_id='%s'", $service["check_period"]);
			$checkq=mysql_query($checkq);
			$check_period=mysql_result($checkq, 0);
			printf('<a href="hostgroups.php?hostgroup_id=%s"><tr STYLE="cursor: hand"><td>%s</td><td>%s</td><td>%s</td><td>', $hostgroup_id, $service["service_description"], $check_period, $notification_period);
			$service_id=$service["service_id"];
			$cgquery=mysql_query("SELECT contactgroups.contactgroup_name FROM contactgroups, service_contactgroups WHERE service_contactgroups.service_id='$service_id' AND contactgroups.contactgroup_id=service_contactgroups.contactgroup_id ORDER BY contactgroups.contactgroup_name");
			while ($mycg=mysql_fetch_array($cgquery)) {
				printf('%s<br>', $mycg["contactgroup_name"]);
			}
			echo "</tr></a>";
		}
		echo "</table>";
	}
	?>
	
<center><br>
<b>Service Dependancies</b> </center>
<table border="1" align="center">
<?
$sdepquery=mysql_query("SELECT * FROM servicedependency WHERE dependent_host_id='$host_id' ORDER BY host_name, service_description");
if (mysql_num_rows($sdepquery) == 0) {
	echo "<tr><td>No Service Dependencies Defined";
} else {
	while ($sdep = mysql_fetch_array($sdepquery)) {
		printf ('<tr><td><b>%s</b> depends on <b>%s</b> on <b>%s</b><br>Execution Criteria (%s), Notification Criteria (%s)</td><td><a href="hosts.php?action=RemoveServiceDep&servicedependency_id=%s&host_id=%s">Remove</a></td></tr>', $sdep["dependent_service_description"], $sdep["service_description"], $sdep["host_name"], $sdep["execution_failure_criteria"], $sdep["notification_failure_criteria"], $sdep["servicedependency_id"], $host_id);

	}
}
echo '</table>';
printf ('<br><center><a href="dependencies.php?dep_host_id=%s">Add Service Dependency</a></center>', $host_id);
?>

			</td>
  </table>

		<br>	
	
<?
}
echo "<br><center>\n";
if ($action == 'hostlookup') {
	echo '<input type="submit" name="submit" value="Submit Info">&nbsp;&nbsp;&nbsp;&nbsp;';
	printf('<input type=hidden name="host_id" value="%s"', $host_id);
	echo '<input type="submit" name="action" value="Duplicate">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;';
} elseif ($action == 'Delete') {
	printf('<a href="hosts.php?action=confirmed&host_id=%s">Yes Delete It !</a>&nbsp;&nbsp;&nbsp;&nbsp;', $host_id);
} else {
	echo '<input type="hidden" name="action" value="AddHost">';
	echo '<input type="submit" name="submit" value="Add Host">&nbsp;&nbsp;&nbsp;&nbsp;';
}

echo $deletedepquery;

?>
<input type="submit" name="action" value="Return to Hosts">
</center>
</form>

