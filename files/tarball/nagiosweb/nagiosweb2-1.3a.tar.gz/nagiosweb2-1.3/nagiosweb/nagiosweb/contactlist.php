<?php
//include("include.php");
include("dbconfig.php");
//include("top.php");

?>
<center><a href="contacts.php">Add New Contact</a></center><br>

<table align="center" border="1" cellpadding="2" cellspacing="0" width="600">
<tr align="center"><td width=200><b>Contact Name</b></td><td width="400"><b>Contact Groups</b></td></tr>
<?
$contactquery = mysql_query("SELECT contact_id, contact_name FROM contacts ORDER BY contact_name");
while ($mycontact = mysql_fetch_array($contactquery)) {
	printf('<tr><td><a href="contacts.php?action=contactlookup&contact_id=%s">%s</a></td><td><table border=1 width=100%%>', $mycontact["contact_id"], $mycontact["contact_name"]); 
	echo "\n";
	$contact_id = $mycontact["contact_id"];
	$groupquery = mysql_query("SELECT DISTINCT contactgroups.contactgroup_name, contactgroups.contactgroup_id FROM contactgroups, contactgroup_members WHERE contactgroup_members.contact_id='$contact_id' AND contactgroups.contactgroup_id=contactgroup_members.contactgroup_id ORDER BY contactgroups.contactgroup_name");
	while ($mygroup = mysql_fetch_array($groupquery)) {
		printf('<tr><td width=100%%><a href="contactgroups.php?contactgroup_id=%s">%s</a></td></tr>', $mygroup["contactgroup_id"], $mygroup["contactgroup_name"]);
	}
	echo "</table></td>\n";
}
?>
</table>

