<?
include("include.php");
include("dbconfig.php");

?>
<form method="post" action="commandhelp.php">
<?
dropdown_resolver("check_command", "command_id", "command_name", $check_command, "command");
?>
<input type=submit name="submit" value="View Help">
</form>
<?
$xcommand="/usr/local/nagios/libexec/" . $command . " -h";
exec($xcommand, $arlines, $returncode);
echo '<table width="600" border="0" align="center" cellpadding="0" cellspacing="0">';
foreach($arlines as $arvalues){
	echo "<tr><td>" . $arvalues . "</td></tr>";
}

?>
