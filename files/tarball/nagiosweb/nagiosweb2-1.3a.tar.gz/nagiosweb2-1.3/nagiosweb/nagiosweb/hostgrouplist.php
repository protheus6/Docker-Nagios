<?php
//include("include.php");
include("dbconfig.php");

if ($hostgroup_name) {
	$insertquery=mysql_query("INSERT INTO hostgroups SET hostgroup_name='$hostgroup_name'");
	$hostgroup_id=mysql_insert_id();
	header("Location:hostgroups.php?hostgroup_id=$hostgroup_id&hostgroup_name=$hostgroup_name");
}

//include("top.php");


?>
<center><form action="hostgrouplist.php" method="post">
<input type="text" name="hostgroup_name">&nbsp;&nbsp;<input type="submit" name="AddHostGroup" value="Add Host Group">
</form></center>
<table align="center" border="1" cellpadding="2" cellspacing="0" width="700">
  <tr align="center">
  	<td><strong>Host Group Name</strong></td>
    <td><strong>Members</strong></td>
    <td><strong>Services</strong></td>
  </tr>
<?
$hgquery = mysql_query("SELECT * FROM hostgroups WHERE alias='' ORDER BY hostgroup_name");
while ($myhg=mysql_fetch_array($hgquery)) {
	printf('<tr valign=top><td><a href="hostgroups.php?hostgroup_id=%s">%s</a></td><td><table border=1 width=100%%><tr>', $myhg["hostgroup_id"], $myhg["hostgroup_name"]);
	$hostgroup_id = $myhg["hostgroup_id"];
	$i=0;
	$memberquery = mysql_query("SELECT hosts.host_id, hosts.host_name FROM hosts, hostgroup_members WHERE hostgroup_members.hostgroup_id='$hostgroup_id' and hosts.host_id = hostgroup_members.host_id ORDER BY hosts.host_name");
	while ($mymember=mysql_fetch_array($memberquery)) {
		if ($i>2) {
			echo '</tr><tr>';
			$i=0;
			}
		$i++;
		printf("<td align=center width=33%%><a href='hosts.php?action=hostlookup&host_id=%s'>%s</a></td>\n", $mymember["host_id"], $mymember["host_name"]);
	}
	echo "</table></td><td valign=top><table border=1 width=100%>";
	$servicequery = mysql_query("SELECT DISTINCT service_id, service_description FROM services WHERE hostgroup_id='$hostgroup_id'");
	while ($myservice=mysql_fetch_array($servicequery)) {
		printf("<tr align=center><td><a href='services.php?action=servicelookup&service_id=%s'>%s</a></td></tr>", $myservice["service_id"], $myservice["service_description"]);
		} 
	echo "</table>";	
}
?>
</td></tr>

</table>

