<?php

include("include.php");
include("dbconfig.php");

switch($action) {
	
	case "Return to Check Commands":
	header("Location:checkcommandlist.php");
	break;
	
	case commandsave:
	$updatequery=mysql_query("UPDATE command SET command_name='$command_name', command_line='$command_line', help_text='$help_text' WHERE command_id='$command_id'");
	header("Location:checkcommands.php?action=cclookup&command_id=$command_id");	
	break;

	case Delete:
	$usecount=0;
	$hostquery=mysql_query("SELECT host_name FROM hosts WHERE check_command='$command_id' OR event_handler='$command_id'");
	$usecount=$usecount + mysql_num_rows($hostquery);
	while ($myhost=mysql_fetch_array($hostquery)) {
		printf('<center>Host <font color=red>%s</font><br>', $myhost["host_name"]);
	}
	$servicequery=mysql_query("SELECT service_description FROM services WHERE check_command='$command_id' OR event_handler='$command_id'");
	$usecount=$usecount + mysql_num_rows($servicequery);
	while ($myserv=mysql_fetch_array($servicequery)) {
		printf('<center>Service <font color=red>%s</font><br>', $myserv["service_description"]);
	}
	if ($usecount > 0) {
		printf('<center>These objects use the %s check command, you will need to change them before you can delete it.<br>', $timeperiod_name);
	} else {
		$delquery =mysql_query("DELETE FROM command WHERE command_id='$command_id'");
		header("Location:checkcommandlist.php");	
	}
	break;
	
	case AddCommand:
	$insertquery=mysql_query("INSERT INTO command SET command_name='$command_name', command_line='$command_line', help_text='$help_text'");
	$command_id=mysql_insert_id();
	header("Location:checkcommands.php?action=cclookup&command_id=$command_id");
	break;
	
	case cclookup:
	$query=mysql_query("SELECT * FROM command WHERE command_id='$command_id'");
	extract (mysql_fetch_array($query));
	break;	

}
	
?>

<form action="checkcommands.php" method="post">
<input type="hidden" name="command_id" value="<? echo $command_id ?>">
<input type="hidden" name="action" value="commandsave">

<center>
<?
if ($action == 'cclookup') {
	echo '<input type="submit" name="submit" value="Submit Info">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Return to Check Commands">';
} else {
	echo '<input type="hidden" name="action" value="AddCommand">';
	echo '<input type="submit" name="submit" value="Add Check Command">&nbsp;&nbsp;&nbsp;&nbsp;';
}	
?>
</center><br>
<table align="center" border="1" cellspacing="2" cellpadding="0" width="600">
<tr><td colspan="2" align="center"><b>Check Command Details</b></td></tr>
<tr>
    <td><strong>Command Name:</strong></td>
    <td><input type=text name="command_name" value="<? echo $command_name ?>"></td></tr>
<tr>
    <td><strong>Command Line:</strong></td>
    <td><textarea name="command_line" cols=45 rows="2"><? echo $command_line ?></textarea></td></tr>
<tr>
    <td><strong>Command Help Text:</strong></td>
    <td><textarea name="help_text" cols=45 rows="4"><? echo $help_text ?></textarea></td></tr>
</table>
<center><br>
<?
if ($action == 'cclookup') {
	echo '<input type="submit" name="submit" value="Submit Info">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" name="action" value="Return to Check Commands">';	
} else {
	echo '<input type="hidden" name="action" value="AddCommand">';
	echo '<input type="submit" name="submit" value="Add Check Command">&nbsp;&nbsp;&nbsp;&nbsp;';
}	
?>
</center><br>

	