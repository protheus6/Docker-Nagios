<?php
//include("include.php");
include("dbconfig.php");
//include("top.php");

?>
<center><a href="notifications.php">Add New Notification</a></center><br>

<table align="center" border="1" cellpadding="2" cellspacing="0">
<tr align="center"><td width=150><b>Notification Command Name</b></td><td width=150><b>Notification Command Line</b></td></tr>
<?
$commquery=mysql_query("SELECT * FROM notify ORDER BY command_name");
while ($mycc=mysql_fetch_array($commquery)) {
	printf('<tr><td><a href="notifications.php?action=cclookup&command_id=%s">%s</a></td><td>%s</td></tr></a>', $mycc["command_id"], $mycc["command_name"], $mycc["command_line"]);
}
?>
</table>