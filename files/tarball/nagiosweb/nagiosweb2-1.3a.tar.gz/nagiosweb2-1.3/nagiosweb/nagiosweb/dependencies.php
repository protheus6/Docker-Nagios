<?php
include("include.php");
include("dbconfig.php");

$execution_failure_criteria_array=array('OK', 'Warn', 'Unkn', 'Crit');
$execution_failure_criteria_default_array=array('Warn', 'Unkn', 'Crit');
$notification_failure_criteria_array=array('OK', 'Warn', 'Unkn', 'Crit');
$notification_failure_criteria_default_array=array('Warn', 'Unkn', 'Crit');

$execution_failure_criteria = checkbox_values('execution_failure_criteria', $execution_failure_criteria_array);
$notification_failure_criteria = checkbox_values('notification_failure_criteria', $notification_failure_criteria_array);

if ($dep_host_id && $dep_service_description && $host_id && $service_description && $notification_failure_criteria <> '' && $execution_failure_criteria <> '') {
//	$dep_service_description = checkbox_values('dep_service_description', $dep_service_description);
	$dep_host_namequery=mysql_query("SELECT host_name FROM hosts WHERE host_id='$dep_host_id'");
	$dep_host_name=mysql_result($dep_host_namequery, 0);
	$host_namequery=mysql_query("SELECT host_name FROM hosts WHERE host_id='$host_id'");
	$host_name=mysql_result($host_namequery, 0);
	foreach ($dep_service_description as $dep_service) {
		foreach ($service_description as $service) {
			$insertquery = mysql_query("INSERT INTO servicedependency SET dependent_host_name='$dep_host_name', dependent_host_id='$dep_host_id', dependent_service_description='$dep_service', host_name='$host_name', host_id='$host_id', service_description='$service', execution_failure_criteria='$execution_failure_criteria', notification_failure_criteria='$notification_failure_criteria', inherits_parent='$inherits_parent'");
		}
	}
	header("Location:hosts.php?action=hostlookup&host_id=$dep_host_id");
}

?>
<center>
<div align="center"><b>Service Dependencies</b></div>
<form action="dependencies.php" method="post" name="hostgroupform">
<table align="center" border="1">
<tr> 
<td><b>Host</b></td>
<td><b>Service</b></td>
<td>&nbsp;&nbsp;</td>
<td><b>Host</b></td>
<td><b>Service</b></td>
</tr>
<tr><td>
<?
// dropdown_resolver("dep_host_id", "host_id", "host_name", $dep_host_id, "hosts");
$dep_host_namequery=mysql_query("SELECT host_name FROM hosts WHERE host_id='$dep_host_id'");
$dep_host_name=mysql_result($dep_host_namequery, 0);
echo $dep_host_name;
?>

<input type=hidden name="dep_host_id" value="<? echo $dep_host_id ?>">
</td><td>
<?
if ($dep_host_id) {
	$depquery = mysql_query("SELECT DISTINCT services.service_id, services.service_description FROM services, hostgroup_members WHERE services.host_id='$dep_host_id' OR (services.hostgroup_id=hostgroup_members.hostgroup_id AND hostgroup_members.host_id='$dep_host_id')");
	echo '<select name="dep_service_description[]" multiple>';
	while ($mydep = mysql_fetch_array($depquery)) {
		$searchresult = array_search($mydep["service_description"], $dep_service_description, true);
		if ($searchresult === FALSE) {
			$checked = '';
		} else {
			$checked = 'SELECTED';
		}
		printf('<option value="%s" %s>%s</option>', $mydep["service_description"], $checked, $mydep["service_description"]);
	}
} else {
	echo "Select a Host";
}
?>
</td>
<td>Depends On</td>
<td>
<?
dropdown_resolver("host_id", "host_id", "host_name", $host_id, "hosts");
?>
</td><td>
<?
if ($host_id) {
	$query = mysql_query("SELECT DISTINCT services.service_id, services.service_description FROM services, hostgroup_members WHERE services.host_id='$host_id' OR (services.hostgroup_id=hostgroup_members.hostgroup_id AND hostgroup_members.host_id='$host_id')");
	echo '<select name="service_description[]" multiple>';
	while ($myq = mysql_fetch_array($query)) {
		$searchresult = array_search($myq["service_description"], $service_description, true);
		if ($searchresult === FALSE) {
			$checked = '';
		} else {
			$checked = 'SELECTED';
		}
		printf('<option value="%s" %s>%s</option>', $myq["service_description"], $checked, $myq["service_description"]);
	}
} else {
	echo "Select a Host";
}
?>

</td>
</tr>
<tr>
    <td colspan="2"><strong>Execution Failure Criteria:</strong></td>
<td colspan="3">
<?
//$execution_failure_criteria = checkbox_values('execution_failure_criteria', $execution_failure_criteria_array);
$execution_failure_criteria = checkbox_resolver('execution_failure_criteria', $execution_failure_criteria_array, $execution_failure_criteria, $execution_failure_criteria_default_array);
?>
</td></tr>
<tr>
    <td colspan="2"><strong>Notification Failure Criteria:</strong></td>
<td colspan="3">
<?
//$notification_failure_criteria = checkbox_values('notification_failure_criteria', $notification_failure_criteria_array);
$notification_failure_criteria = checkbox_resolver('notification_failure_criteria', $notification_failure_criteria_array, $notification_failure_criteria, $notification_failure_criteria_default_array);
?>
</td></tr>
    <td colspan="2"><strong>Inherits Parent:</strong></td>
    <td colspan="3">
<?
$inherits_parent_array=array('Yes', 'No');
radio_button_resolver('inherits_parent', $inherits_parent_array, $inherits_parent, 'Yes');

?>
</td>
	  </table>
<?
if ($notification_failure_criteria) {
	printf('<input type="hidden" value="%s" name="notification_failure_criteria">', $notification_failure_criteria);
}
if ($execution_failure_criteria) {
	printf('<input type="hidden" value="%s" name="execution_failure_criteria">', $execution_failure_criteria);
}
?>
<br><center><input type=submit value="Submit/Refresh"></center>