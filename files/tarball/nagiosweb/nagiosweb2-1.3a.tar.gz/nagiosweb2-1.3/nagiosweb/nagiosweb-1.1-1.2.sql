-- phpMyAdmin SQL Dump
-- version 2.6.4
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Apr 06, 2006 at 01:25 PM
-- Server version: 4.1.14
-- PHP Version: 5.0.5
-- 
-- Database: `nagiosweb-dist`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `servicegroup_members`
-- 

CREATE TABLE `servicegroup_members` (
  `servicegroup_id` int(11) NOT NULL default '0',
  `service_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`servicegroup_id`,`service_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `servicegroup_members`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `servicegroups`
-- 

CREATE TABLE `servicegroups` (
  `servicegroup_id` int(11) NOT NULL auto_increment,
  `servicegroup_name` text NOT NULL,
  `alias` text NOT NULL,
  PRIMARY KEY  (`servicegroup_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `servicegroups`
-- 

